<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FormDetails extends Model
{
    protected $table='form_details';
    protected $fillable = ['name','filename','filepath','created_at','updated_at'];
}
