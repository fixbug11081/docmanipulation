<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ComplaintController extends Controller
{
    public function Index(){
        try{
            return view('complaint.home');
        }catch(\Exception $e){
             return $e->getMessage();
        }     
    }
    public function RenderComplaintForm(){
        try{
        return view('complaint.complaintform');
        }catch(\Exception $e){
             return $e->getMessage();
        } 
    }
    public function SignUp(Request $request){
        try {
              echo "ajeet";die;
                User::create([
                            'name'=>$request->post('name'),
                            'email'=>$request->post('email'),
                            'mobilenumber'=>$request->post('mobilenumber'),
                            'otp'=>$request->post('otp')
                    ]);
        }catch(\Exception $e){
             return $e->getMessage();
        }        
    }
}
