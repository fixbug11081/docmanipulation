<?php
namespace App\Http\Controllers;
use App;
use App\Form;
use App\MetaForm;
use App\MasterField;
use App\FormDetails;
use PhpOffice\PhpWord\IOFactory;
use App\Applicant;
use PDF;
use Illuminate\Http\Request;
use Validator;
use Flash;
use Session;

class FormBuilderController extends Controller
{
    //form buildr
    public function FormBuilder()
    {

        $form = App\MetaForm::all();
        $field = App\MasterField::pluck('name', 'id');
        $formname = App\FormDetails::pluck('name', 'id');
        return view('form', compact('field', 'formname'));
    }

    public function FillForm(Request $request)
    {
        $file_path = "/home/udit/Desktop/register.doc";
        $phpWord = \PhpOffice\PhpWord\IOFactory::load($file_path, 'MsDoc');
        $objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
        foreach ($phpWord->getSections() as $section)
        {
            foreach ($section->getElements() as $element)
            {
                if (method_exists($element, 'getText'))
                {
                    /*echo(preg_replace_callback("/_{2,}/",
                      function($m){
                          static $i=0;
                          $i=$i+1;*/

                    //return $replacement[$i];
                    /*}
                      , 
                      $element->getText() . "<br>"));  */
                    $pattern = array(
                        '/_{2,}/',
                        '/_{2,}/',
                        '/_{2,}/',
                        '/_{2,}/',
                        '/_{2,}/',
                        '/_{2,}/',
                        '/_{2,}/',
                        '/_{2,}/'
                    );
                    echo (preg_replace_callback('/_{2,}/', function ($m)
                    {
                        static $i = 0;
                        $i = $i + 1;
                        $replacement = array(
                            '',
                            'ajeet',
                            'akash',
                            '12/12/2019',
                            '23',
                            'sujeet',
                            'anjana',
                            '01/01/2019',
                            '65'
                        );
                        return $replacement[$i];
                    }
                    , $element->getText() . "<br>"));
                    //$str =  $element->getText()."<br>";
                    //echo $str;
                    
                }
            }
        }

        die;
        $objWriter->save('fill-form.doc');
        header('Content-Description: File Transfer');
        header('Content-Type: application/ms-word');
        header('Content-Disposition: attachment; filename=filled-form.doc');
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Content-Length: ' . filesize('fill-form.doc'));
        readfile('fill-form.doc');
        unlink('fill-form.doc'); // deletes the temporary file
        exit;

        //return response()->download('/home/udit/Downloads/'.'fill-form.doc');
        //return preg_replace('/[�*{2,}]/', ' ', $content);
        
    }

    public function Register()
    {
        return view('register');
    }

    public function Form()
    {
        return view('registerform');
    }

    public function Applicant()
    {
        return view("register", compact('applicant'));
    }

    public function SaveApplicant(Request $request)
    {
        $datas = $request->all();

        Applicant::create(['name' => $request->post('name') , 'gender' => $request->post('gender') , 'gaurdian' => $request->post('gaurdian') , 'address' => $request->post('address') , 'dob' => $request->post('dob') , 'updated_at' => now() , 'created_at' => now()

        ]);

        return view("register", compact('datas'));

    }

    public function Downloads()
    {
        // Fetch all customers from database
        // $datas = Applicant::all();
        

        // Send data to the view using loadView function of PDF facade
        $pdf = PDF::loadView('register', compact('datas'));
        // If you want to store the generated pdf to the server then you can use the store function
        $pdf->save(storage_path() . '_filename.pdf');
        // Finally, you can download the file using download function
        return $pdf->download('customers.pdf');

    }

    public function Streamhtml()
    {
        // var_dump(ini_get('allow_url_fopen'));
        // if($stream = fopen('http://localhost:8000/save-applicant', 'r')) {
        //     // print all the page starting at the offset 10
        //     echo stream_get_contents($stream, -1, 10);
        //     fclose($stream);
        // }
        /*$fp = stream_socket_client("tcp://127.0.0.1:8000/save-applicant", $errno, $errstr);
                if (!$fp) {
                    echo "ERROR: $errno - $errstr<br />\n";
                } else {
                    fwrite($fp, "\n");
                    echo fread($fp, 9000);
                    fclose($fp);
                  }*/

        $ch = curl_init();

        $url = "localhost:8000/save-applicant";
        echo $url;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPGET, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $return = curl_exec($ch);
        curl_close($ch);
        echo $return;

    }

    public function SaveFields(Request $request)
    {
    

        try
        {

            // putting some validation rules for User input
            $validator = Validator::make($request->all() , ['fieldname' => 'required|alpha', 'fieldtype' => 'required', 'method' => 'required', 'label' => 'required', 'sequence' => 'required|integer'

            ]);
            if ($validator->fails())
            {
                $errors = $validator->errors();
                $field = MasterField::pluck('name', 'id');
                $formname = FormDetails::pluck('name', 'id');
                return view('form', compact('formname') , compact('field'))->with('errors', $errors);

                //  back()->with('fail','Invalid input');
                // $msg = $messages[0];
                //$field = MasterField::pluck('name','id');
                //$formname = FormDetails::pluck('name','id');
                // view('form', compact('formname'), compact('field'));
                //reurn back()->with('','');
                // Session::flash('message', $messages);
                // Session::flash('alert-class', 'alert-danger');
                // return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => $msg]);
                
            }

            // if ($validator->fails()) {
            //     //flash($validator->errors());
            //     $formname = FormDetails::pluck('name','id');
            //     $field = MasterField::pluck('name','id');
            //     return view('form', compact('formname'), compact('field'));
            

            // }
            

            Form::create(['fieldname' => $request->post('fieldname') , 'fieldtype' => $request->post('fieldtype') , 'method' => $request->post('method') , 'label' => $request->post('label') , 'sequence' => $request->post('sequence') , 'formid' => $request->post('formname') , 'created_at' => now() , 'updated_at' => now() ]);
            $formname = FormDetails::pluck('name', 'id');
            $field = MasterField::pluck('name', 'id');
            return view('form', compact('formname') , compact('field'))->with('success', 'Data Saved');

        }
        catch(\Exception $e)
        {

            return $e->getMessage();

        }

    }

    //Adding new form
    public function AddForm(Request $request)
    {

        FormDetails::create(['name' => $request->post('name') , 'created_at' => now() , 'updated_at' => now() ]);
        $formname = FormDetails::pluck('name', 'id');
        $field = MasterField::pluck('name', 'id');

        return view('form', compact('formname') , compact('field'));
    }

    public function CreateForm()
    {
        return view('addnewform');
    }

}

