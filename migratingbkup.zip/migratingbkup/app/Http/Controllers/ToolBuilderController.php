<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App;
use App\Form;
use App\FormDetails;
use App\FormFields;
use File;
use DB;
use PDF;
class ToolBuilderController extends Controller
{
    //Genrate form 

	public function GenerateForm(Request $request){
		try{	
			$formid = $request->get('formname');
			$fields = Form::where('formid', $formid)->get();
			$formname = FormDetails::find($request->get('formname'));
		
	    	//form submission route and controller
			$route = '/generate/'.strtolower(preg_replace("/\s/", "-", $formname->name));

			$controller = 'ToolBuilderController@DynamicFormData';
			$view = preg_replace("/\s/", "_", $formname->name);
			FormDetails::where('id',$formid)
			->update([
				'routes'=> $route,
				'controllers'=>$controller,
				'view'=>strtolower($view),
				'table'=>strtolower($view)
			]);


	    	//form create crossponding tables			
			$col = '';
			$tablename = strtolower(preg_replace("/\s/", "_", $formname->name));
			foreach ($fields as $field ) {
				$col = $col.$field->fieldname.' VARCHAR(250) NOT NULL,';
			}

			$sql = 'CREATE TABLE '.$tablename.'(id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,'.
			$col.'reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)';

			DB::statement($sql);		

			

			$html = view('dynamicform',compact('fields'))
					->with(['route'=>$route])->render();
			File::put(resource_path('views')."/".$tablename.'.blade.php', $html);

			return view('dynamicform',compact('fields'))->with(['route'=>$route]);

		}catch(\Exception $e){
			return $e->getMessage();
		}	
	}

	public function FormTool(){
		$formname = FormDetails::pluck('name','id');
		$viewlist = FormDetails::pluck('view','id');
		$htmllist = FormDetails::pluck('templatename','id');


		return view('tools',compact('formname','viewlist','htmllist'));
	}

	public function RenderTemplate(Request $request ){

		$renderview = FormDetails::find($request->templatename);
		$getvalues = "SELECT * FROM  "." `".$renderview->table."` "." where 1";
		$records = DB::select(DB::raw($getvalues));

		$viewhtml = view('template.'.$renderview->templatename,compact('records'))->render();
		return $viewhtml;
	}

	public function ListValue(Request $request){
		$table = FormDetails::find($request->templatename);

		$getcols = 'SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
		WHERE TABLE_NAME = '."'".$table->table."'";
		$cols = DB::select(DB::raw($getcols));

		$getvalues = "SELECT * FROM  "." `".$table->table."` "." where 1";


		$records = DB::select(DB::raw($getvalues));

		return view('listvalue', compact('cols','records'));
	}

	//changed name from  DynamicFormData to DynamicSaveFormData
	public function DynamicSaveFormData(Request $request){

		$tablename = preg_replace('/-/','_',request()->segment(count(request()->segments())));
		$partialsql = '';
		$fieldnames = $fieldvalues = [] ;
		$fieldnames = array_keys($request->all());
		$fieldvalues = array_values($request->all());
		$fieldvalues = array_slice($fieldvalues, 1);

		foreach($fieldnames as $fieldname)
		{
			if($fieldname == '_token' ||  ($fieldname == 'submit'))
				continue;
			$partialsql = $partialsql.$fieldname.",";
		}
		$partialsql = $partialsql.'reg_date';
    		//$partialsql = rtrim($partialsql, ',');
		$partialsql = $partialsql.")VALUES(";
		foreach($fieldvalues as $fieldvalue)
		{

			if($fieldvalue == 'submit')
				continue;
			$partialsql = $partialsql."'".$fieldvalue."'".",";
		}    		
		$partialsql = $partialsql."'".date('Y-m-d')."'";
    		//$partialsql = rtrim($partialsql, ',');
		

		$sql = 'insert into '. $tablename.'('.$partialsql.' )';


		DB::statement($sql);
		return view($tablename)->with('message','Data saved');

	}

	public function GetForm(Request $request){

		$formdetail = FormDetails::find($request->get('view'));    		
		return view($formdetail->view);
	}

	public function Editor(){

		return view('editor');
	}


	public function PDFDownloads(Request $request){

		$table = FormDetails::find($request->templatename);
		$getvalues = "SELECT * FROM  "." `".$table->table."` "." where 1";
		$records = DB::select(DB::raw($getvalues));

		$filename = $table->templatename."_".date('d_m_Y');
		$pdf = PDF::loadView('template.'.$table->templatename,compact('records'));
		$pdf->save(storage_path().'filename.pdf');
        // Finally, you can download the file using download function
		return $pdf->download($filename.'.pdf');

	}


	public function ViewPDF(Request $request){

		$table = FormDetails::find($request->templatename);
		$getvalues = "SELECT * FROM  "." `".$table->table."` "." where 1";
		$records = DB::select(DB::raw($getvalues));
		$filename = $table->templatename."_".date('d_m_Y');
		$pdf = PDF::loadView('template.'.$table->templatename,compact('records'));
		return $pdf->stream('result.pdf', array('Attachment'=>0)); 
	}

	public function PDFText(Request $request){
		$pdf = PDF::loadView($table->templatename,compact('records'));
		return $pdf->stream('result.pdf', array('Attachment'=>0)); 
	}


	public function HtmlEditor(Request $request){
		//return view('htmleditor');
		return view('tryit.index');
	}

	public function SaveHtml(Request $request){
		$filename = $request->post('filename');
		$path = resource_path()."/views/".$filename.'.blade.php';
		
		$fp = (file_exists($path))? fopen($path, "a+") : fopen($path, "w+");
		//$fp = fopen($name.".blade.php", "w") or die("Unable to open file!");
		$editorCode = $request->post('ta');
		//$editorCode = htmlspecialchars_decode($editorCode);
		
		fwrite($fp, $editorCode);
		fclose($fp);
		return "File Saved Successfully";
	}


	/**** Customer flow try now ***/

	public function TryNow(){

		$htmllist = FormDetails::pluck('templatename','id');
		$formname = FormDetails::pluck('name','id');
		return  view('selecttemplate', compact('htmllist','formname'));
	}



	public function SelectForm(Request $request){
		try{
		    
			$formid = $request->get('formname');
			$fields = FormFields::where('formid', $formid)->get();
			$formname = FormDetails::find($request->get('formname'));
			$viewname = $formname->view;
		
			return view('form.'.$viewname);
		}catch(\Exception $e){
			return $e->getMessage();
		}	
	}


	public function DynamicFormData(Request $request){


		$tablename = preg_replace('/-/','_',request()->segment(count(request()->segments())));
		$partialsql = '';
		$fieldnames = $fieldvalues = [] ;
		$fieldnames = array_keys($request->all());
		$fieldvalues = array_values($request->all());
		$fieldvalues = array_slice($fieldvalues, 1);

		foreach($fieldnames as $fieldname)
		{
			if($fieldname == '_token' ||  ($fieldname == 'submit'))
				continue;
			$partialsql = $partialsql.$fieldname.",";
		}
		$partialsql = $partialsql.'reg_date';
    		//$partialsql = rtrim($partialsql, ',');
		$partialsql = $partialsql.")VALUES(";
		foreach($fieldvalues as $fieldvalue)
		{

			if($fieldvalue == 'submit')
				continue;
			$partialsql = $partialsql."'".$fieldvalue."'".",";
		}    		
		$partialsql = $partialsql."'".date('Y-m-d')."'";
    		//$partialsql = rtrim($partialsql, ',');
		

		$sql = 'insert into '. $tablename.'('.$partialsql.' )';


		DB::statement($sql);


		//save file 
		$getvalues = "SELECT * FROM  "." `".$tablename."` "." 
		order by `id` desc limit 1";

		$records = DB::select(DB::raw($getvalues));
		$template = FormDetails::where('table', $tablename)->pluck('templatename');	
		$template = 'template.'.$template[0];
	
						
		$htmlfile = view($template,compact('records'))->render();
	
		//return file_get_contents($htmlfile);
		return view('tryeditor', ['htmlfile'=>$htmlfile]);
		//$filename = $table->templatename."_".date('d_m_Y');


		//return view($tablename)->with('message','Data saved');

	}

	public function DocEditor(){

		return view('doceditor');
	}

	/****End customer flow try now ***/

}
