<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use App\FormDetails;
use App\MasterField;
use Validator;
use App\Form;
use DB;
use File;
use Auth;
use Session;
use Redirect;
class AdminController extends Controller
{
    public function __construct(Request $request )
    {
   
    }

    public function CreateForm(Request $request)
    {
       return view('admin.addnewform');
    
    }
    
    public function EditForm(Request $request){
        $form = FormDetails::pluck('name','id');
        return view('admin.editform',compact('form'));
    }
    //Adding new form
    public function AddForm(Request $request)
    {

        $validator = Validator::make($request->all() , ['name' => 'required|alpha']);

        if ($validator->fails())
        {
            $errors = $validator->errors();
            return view('admin.form')
                ->with('errors', $errors);
        }

        $createdform = FormDetails::create(['name' => $request->post('name') , 'created_at' => now() , 'updated_at' => now() ]);
        $formname = FormDetails::where('id',$createdform->id)->pluck('name', 'id');
        $field = MasterField::pluck('name', 'id');
        $optiongroupfield = Form::where('groupfields','1')->where('formid',$createdform->id)->pluck('label','id');
        $urlsegment = \Request::segment(2);
       
        return view('admin.form',compact('field','formname','optiongroupfield'))->with('urlsegment', $urlsegment);
    }
   
     //Edit existing form
    public function EditFormFields(Request $request)
    {
     
        $validator = Validator::make($request->all() , ['listofform' => 'required']);
            
        if ($validator->fails())
        {
            $errors = $validator->errors();
            $form = FormDetails::pluck('name','id');
            return view('admin.editform',compact('form'))
                ->with('errors', $errors);
        }
        $id = $request->post('listofform');
       
        //$createdform = FormDetails::create(['name' => $request->post('name') , 'created_at' => now() , 'updated_at' => now() ]);
        $formname = FormDetails::where('id',$id)->pluck('name', 'id');

        $field = MasterField::pluck('name', 'id');
        $optiongroupfield = Form::where('groupfields','1')->where('formid',$id)->pluck('label','id');
        $attributes = Form::where('formid',$id)->where('groupfields','0')->get();
        $table = FormDetails::where('id',$id)->pluck('name');
        $urlsegment = \Request::segment(2); 
        
        return view('admin.form',compact('field','formname','optiongroupfield','attributes'))->with('tablename',$table[0])->with('formid',$id)->with('urlsegment',$urlsegment);
    }


    public function SaveFields(Request $request)
    {
   
        try
        {
            // putting some validation rules for User input
            $validator = Validator::make($request->all() , ['fieldname' => 'required|alpha', 'fieldtype' => 'required', 'label' => 'required', 'sequence' => 'required|integer'
            ]);
            $optiongroupfield = Form::where('groupfields','1')->pluck('label','id');
               
            if ($validator->fails())
            {
                $errors = $validator->errors();
                $field = MasterField::pluck('name', 'id');
                $formname = FormDetails::pluck('name', 'id');
                return view('admin.form', compact('field','formname','optiongroupfield'))->with('errors', $errors);

            }
            $fieldname = $request->post('fieldname');
            $fieldname = strtolower($fieldname);
            $fieldtype = $request->post('fieldtype');
            $ttl = $request->post('tooltips');
            $tooltips = isset($ttl)?$ttl:null;
          
            if($fieldtype == 3){
                $optiongroupfieldid=$request->post('optiongroupfield');
                
            }else{
                $optiongroupfieldid=0;
            }
            if($request->has('boxflag'))
            {
                $boxflag = 1;
            }    
            else
            {
                $boxflag = 0;
            }
            if($request->has('plainfield')){
                $groupfields=0;
               
            }else{
                  if($request->has('groupfields'))
                    {
                        $groupfields = 1;
                    }    
                    else
                    {
                        $groupfields = 0;
                      
                    }  
                   
              
            }
        
            
           /* print_r(['fieldname' => $fieldname , 'fieldtype' => $request->post('fieldtype') , 
            'label' => $request->post('label') ,'sqrflag'=>$boxflag,'groupfields'=>$groupfields,
            'optiongroupfieldid'=>$optiongroupfieldid,'sequence' => $request->post('sequence') , 
            'formid' => $request->post('formname') ,'tooltips'=>$tooltips, 
            'created_at' => now() , 'updated_at' => now() ]);*/
            $created =  Form::create(['fieldname' => $fieldname , 'fieldtype' => $request->post('fieldtype') , 
            'label' => $request->post('label') ,'sqrflag'=>$boxflag,'groupfields'=>$groupfields,
            'optiongroupfieldid'=>$optiongroupfieldid,'sequence' => $request->post('sequence') , 
            'formid' => $request->post('formname') ,'tooltips'=>$tooltips,'created_at' => now() ,
            'updated_at' => now() ]);
           
            $formname = FormDetails::where('id',$request->post('formname'))->pluck('name', 'id');
            $field = MasterField::pluck('name', 'id');
            $id = $request->post('formname');
            $attributes = Form::where('formid',$id)->get();
            $urlsegment = \Request::segment(2);
           
            return view('admin.form', compact('field','formname','optiongroupfield','attributes'))->with('urlsegment',$urlsegment)->with('success', 'Data Saved');
        }catch(\Exception $e){

            return $e->getMessage();

        }

    }

    public function ListValue(Request $request)
    {
        $table = FormDetails::find($request->templatename);

        $getcols = 'SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
		WHERE TABLE_NAME = ' . "'" . $table->table . "'";
        $cols = DB::select(DB::raw($getcols));

        $getvalues = "SELECT * FROM  " . " `" . $table->table . "` " . " where 1";

        $records = DB::select(DB::raw($getvalues));
       
        return view('admin.listvalue', compact('cols', 'records'));
    }

    public function CheckFields()
    {

        $htmllist = FormDetails::pluck('templatename', 'id');
        return view('admin.listfields', compact('htmllist'));
    }

    public function CreateView()
    {

        try
        {
            // $validator = Validator::make([$request->all(), ['name'=>'required']]);
            // if($validator->fails()){
            // 	$errors = $validator->errors();
            // 	return view('admin.createview')->with('errors',$errors);
            // }
            $formname = FormDetails::pluck('name', 'id');
            return view('admin.createview', compact('formname'))->with('message', '');

        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }

    }

    /*** Generate form ***/

    public function GenerateForm(Request $request)
    {
        try
        {
            $formid = $request->get('formname');

            $fields = Form::where('formid', $formid)->get();

            $formname = FormDetails::find($request->get('formname'));

            //form submission route and controller
            $route = '/generate/doc/' . strtolower(preg_replace("/\s/", "-", $formname->name));

            $controller = 'ToolBuilderController@DynamicFormData';
            $view = preg_replace("/\s/", "_", $formname->name);
            FormDetails::where('id', $formid)->update(['routes' => $route, 'controllers' => $controller, 'view' => strtolower($view) , 'table' => strtolower($view) ]);

            //form create crossponding tables
            $col = '';
            $tablename = strtolower(preg_replace("/\s/", "_", $formname->name));
            foreach ($fields as $field)
            {
                $col = $col . $field->fieldname . ' VARCHAR(250) NOT NULL,';
            }

            if (!Schema::hasTable($tablename))
            {

                $sql = 'CREATE TABLE ' . $tablename . '(id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,' . $col . 'reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)';
                DB::statement($sql);
         
                $html = view('dynamicform', compact('fields'))->with(['route' => $route])->render();
                File::put(resource_path('views') . "/form/" . $tablename . '.blade.php', $html);
                $formname = FormDetails::pluck('name', 'id');
                return view('admin.createview', compact('formname'))->with('message', 'Form created successfully.');
            }
            elseif(Schema::hasTable($tablename))
            {
                //get all columnns of table
                $columns = Schema::getColumnListing($tablename);
                $fields = Form::where('formid',$formid)->whereNotIn('fieldname',$columns)->get()->toArray();
                $cols='';
                foreach ($fields as $field)
                {
                  $cols= $cols.' ADD '.$field['fieldname'] .' VARCHAR(250) NOT NULL,';
                }
                $cols = rtrim($cols,",");
                //Alter existing table
                $sql =' ALTER TABLE '.strtolower($tablename).$cols;
                DB::statement($sql);
                $fields = Form::where('formid', $formid)->get();
                $html = view('dynamicform', compact('fields'))->with(['route' => $route])->render();
                File::put(resource_path('views') . "/form/" . $tablename . '.blade.php', $html);
                $formname = FormDetails::pluck('name', 'id');
                return view('admin.createview', compact('formname'))->with('message', 'Modify view ');
            }else{
                $formname = FormDetails::pluck('name', 'id');
                return view('admin.createview', compact('formname'))->with('message', 'View already created.');
            
            }
            //return view('dynamicform',compact('fields'))->with(['route'=>$route]);
            
        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }
    }

    //Create  new template
    public function CreateTemplate()
    {

        try
        {

            $formname = FormDetails::pluck('name', 'id');
            return view('admin.createtemplate', compact('formname'))->with('message', '');

        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }

    }

    public function Templateeditor(Request $request)
    {

        try
        {
            $fail = null;
            $formname = $request->get('formname');

            $templatename = FormDetails::where('id', $formname)->get();
            foreach ($templatename as $value)
            {
                $name = $value->name;
            }
            FormDetails::where('id', $formname)->update(['templatename' => $name]);

            $fields = Form::where('formid', $formname)->pluck('fieldname');

            return view('admin.templateeditor')
                ->with(['fail' => $fail, 'templatename' => $name, 'fieldsname' => $fields]);
        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }
    }

    public function SaveTemplate(Request $request)
    {

        $validator = Validator::make($request->all() , ['templatecontent' => 'required']);

        if ($validator->fails())
        {
            return view('admin.templateeditor')
                ->with('fail', 'Template data is not fill');
        }
        
        

        $phpWord = new \PhpOffice\PhpWord\PhpWord();
        \PhpOffice\PhpWord\Settings::setOutputEscapingEnabled(true);
        $section = $phpWord->addSection();
        $templatetxt = $request->post('templatecontent');
        //echo $templatetxt; die;
        
        $section->addText($templatetxt);
       // $section->addText(str_replace("&nbsp;", '', strip_tags($templatetxt)));
        
        $objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
        //$filename = $request->post('filename');
        $filename = request()->segment(count(request()->segments()));
        $path = storage_path() . "/app/template/" . $filename . '.docx';
        $objWriter->save($path);
        $templatename = request()->segment(count(request()->segments()));
        $id = FormDetails::where('name', $templatename)->pluck('id');

        $savedfile = FormDetails::where('id', $id[0])
        ->update(['filename' => $filename.".docx", 'filepath' => $path]);
        
        // $fp = (file_exists($path))? fopen($path, "a+") : fopen($path, "w+");
        // $editorCode =$request->post('templatecontent');
        // fwrite($fp, $editorCode);
        // fclose($fp);
        $formname = FormDetails::pluck('name', 'id');
        return view('admin.createtemplate', compact('formname'))->with('message', 'Template File Saved Successfully');

    }

    public function TemplateEdit(Request $request)
    {
        try
        {
            $fail = null;
            $formname = $request->get('formname');

            $templatename = FormDetails::where('id', $formname)->get();
            foreach ($templatename as $value)
            {
                $name = $value->name;
            }
            $editcontent = file_get_contents(resource_path() . '/views/template/' . $name . '.blade.php');

            return view('admin.editmodetemplateeditor')->with(['fail' => $fail, 'templatename' => $name, 'editcontent' => $editcontent]);
        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }
    }

    public function UploadTemplate(Request $request)
    {
        try
        {
            $fail = null;
            $message = null;
            $formname = $request->get('formname');
            $templatename = FormDetails::where('id', $formname)->get();
            foreach ($templatename as $value)
            {
                $name = $value->name;
            }
            FormDetails::where('id', $formname)->update(['templatename' => $name]);
            $fields = Form::where('formid', $formname)->pluck('fieldname');
            return view('admin.uploadtemplate')
                ->with(['fail' => $fail, 'templatename' => $name, 'fieldsname' => $fields, 'message' => $message]);
        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }

    }

    public function TemplateFileUpload(Request $request)
    {

        try
        {
            $validator = Validator::make($request->all() , ['templatefile' => 'required|file|max:5000'

            ]);
            $templatename = request()->segment(count(request()->segments()));
            $id = FormDetails::where('name', $templatename)->pluck('id');

            $fields = Form::where('formid', $id[0])->pluck('fieldname');

            if ($validator->fails())
            {

                $errors = $validator->errors();
                print_r($errors);
                return view('admin.uploadtemplate')->with(['errors' => $errors, 'message' => 'Error  in upload', 'templatename' => $templatename, 'fieldsname' => $fields]);
            }

            //if(hasFile('templatefile')){
            $file = $request->file('templatefile');
            $originalname = $file->getClientOriginalName();
            $extension = $file->getClientOriginalExtension();
            $path = $file->storeAs("/template", $originalname);
            FormDetails::where('id', $id[0])->update(['filename' => $originalname, 'filepath' => storage_path() . '/template/' . $originalname

            ]);

            return view('admin.uploadtemplate')->with(['message' => 'File uploaded Successfully', 'templatename' => $templatename, 'fieldsname' => $fields]);

        }
        catch(\Exception $e)
        {

            return $e->getMessage();
        }
    }
    
    public function GetOptions($formid){
        try{
        
          $optiongroupfield = Form::where('groupfields','1')->where('formid',$formid)->pluck('label','id');
           return Response::json([
               'data'=>$optiongroupfield,
               'status'=>200
               ]);
        }catch(\Exception $e){
             return $e->getMessage();
        }       
    }
    //After deletion of fields in edit form box
    public function ViewAfterdeletefields($id){
       
        $formname = FormDetails::where('id',$id)->pluck('name', 'id');
        
        $field = MasterField::pluck('name', 'id');
        $optiongroupfield = Form::where('groupfields','1')->where('formid',$id)->pluck('label','id');
        $attributes = Form::where('formid',$id)->get();
        $table = FormDetails::where('id',$id)->pluck('name');
 
        
        return view('admin.form',compact('field','formname','optiongroupfield','attributes'))->with('tablename',$table[0])->with('formid',$id);
    }
    //Delete fields from form 
    public function DeleteFields(Request $request){
        try{
            $tablename = last(request()->segments());
            $formid = request()->segment(4);
            $fieldcheckbox = $request->get('fieldcheckbox');
            $cols = '';
           
            foreach ($fieldcheckbox as $fieldtodelete){
                $cols = $cols.' drop column '.$fieldtodelete.",";
               
            } 
            $cols = rtrim(",",$cols);
            $sql = 'alter table '.strtolower($tablename).''.$cols;
            
            DB::statement($sql);
            
            foreach ($fieldcheckbox as $fieldtodelete){
              
                Form::where('formid', $formid)->where('fieldname',$fieldtodelete)->delete();
            } 
            $fields = Form::where('formid', $formid)->get();
            $formname = FormDetails::find($formid);
            $route = '/generate/doc/' . strtolower(preg_replace("/\s/", "-", $formname->name));

    
            $html = view('dynamicform', compact('fields'))->with(['route' => $route])->render();
            File::put(resource_path('views') . "/form/" . $tablename . '.blade.php', $html);
            return Redirect::to('/admin/edit-application-form/'.$formid);
            //$this->ViewAfterdeletefields($formid);
        }catch(\Exception $e){
            return $e->getMessage();
        }
    }
    
    
    
    
    