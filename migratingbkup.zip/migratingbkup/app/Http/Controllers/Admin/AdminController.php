<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use App\FormDetails;
use App\MasterField;
use App\GroupFields;
use Validator;
use App\Form;
use App\GenericFields;
use App\FormFields;
use DB;
use File;
use Auth;
use Session;
use Redirect;
use Illuminate\Support\Facades\Input;
class AdminController extends Controller
{
    public function __construct(Request $request)
    {

    }

    public function CreateForm(Request $request)
    {
        return view('admin.addnewform');

    }

    public function EditForm(Request $request)
    {
        $form = FormDetails::pluck('name','id');
        return view('admin.editform', compact('form'));
    }
    //Adding new form
    public function AddForm(Request $request)
    {
        try
        {
            $validator = Validator::make($request->all() , ['name' => 'required|alpha']);

            if ($validator->fails())
            {
                $errors = $validator->errors();
                return view('admin.form')
                    ->with('errors', $errors);
            }

            $createdform = FormDetails::create(['name' => $request->post('name') , 'created_at' => now() , 'updated_at' => now() ]);
            $formname = FormDetails::where('id', $createdform->id)
                ->pluck('name', 'id');
            $field = MasterField::pluck('name', 'id');
            $optiongroupfield = Form::where('groupfields', '1')->where('formid', $createdform->id)
                ->pluck('label', 'id');
            $urlsegment = \Request::segment(2);
            $genericfields = GenericFields::all();
            $groupfields = GroupFields::all();
            return view('admin.form', compact('field', 'formname', 'genericfields', 'groupfields', 'optiongroupfield'))->with('urlsegment', $urlsegment);
        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }
    }

    //Add new row in form as fields
    public function AddNewRow(Request $request)
    {

        $num = $request->get('nooffields');
        foreach ($num as $n)
        {
            echo "  <tr>
                                        <td scope='row' style='vertical-align: middle;'>{{$j}}</td>
                                        <td>
                                            <div class='form-group' style='position:relative;width:200px;'>
                                                <select class='form-control-select' style='position:absolute;width:200px;' onchange='document.getElementById('displayValue').value=this.options[this.selectedIndex].text; document.getElementById('idValue').value=this.options[this.selectedIndex].value;'>
                                                    <option></option>
                                                    @foreach($genericfields as $genericfield)
                                                    <option value={{$genericfield->id}}>{{$genericfield->genericfield}}</option>
                                                    @endforeach
                                                </select>
                                                <input type='text' name='displayValue' id='displayValue' placeholder='add/select a value' onfocus='this.select()' style='position:absolute;top:1px;left:2px;width:175px;border:0px;    padding: 5px;'>
                                                <input name='idValue' id='idValue' type='hidden'>
                                            </div>
                                        </td>
                                        <td>
                                            <div class='form-group'>
                                                <!--{{Form::label('Field Type')}}-->
                                                {{Form::select('fieldtype', $field, null, ['class'=>'form-control-select', 'id'=>'fieldtype'])}}

                                            </div>
                                        </td>
                                        <td>
                                            <div class='form-group'>
                                                <button type='button' class='form-control-input btn btn-default dropdown dropdown-toggle' data-toggle='dropdown'>Address Options <span class='caret'></span></button>
                                                <ul class='dropdown-menu'>
                                                    <li>
                                                        <a href='#' class='sel' data-value='option1' tabIndex='-1'>
                                                            <input type='checkbox' />&nbsp;Building</a>
                                                    </li>
                                                    <li>
                                                        <a href='#' class='sel' data-value='option2' tabIndex='-1'>
                                                            <input type='checkbox' />&nbsp;Street</a>
                                                    </li>
                                                    <li>
                                                        <a href='#' class='sel' data-value='option3' tabIndex='-1'>
                                                            <input type='checkbox' />&nbsp;City</a>
                                                    </li>
                                                    <li>
                                                        <a href='#' class='sel' data-value='option4' tabIndex='-1'>
                                                            <input type='checkbox' />&nbsp;State</a>
                                                    </li>
                                                    <li>
                                                        <a href='#' class='sel' data-value='option5' tabIndex='-1'>
                                                            <input type='checkbox' />&nbsp;PIN</a>
                                                    </li>
                                                    <li>
                                                        <a href='#' class='sel' data-value='option6' tabIndex='-1'>
                                                            <input type='checkbox' />&nbsp;Country</a>
                                                    </li>
                                                    <li>
                                                        <a href='#' class='sel' data-value='option6' tabIndex='-1'>
                                                            <input type='checkbox' />&nbsp;Other</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </td>
                                        <td style='text-align:center;vertical-align: middle;'>
                                            <div class='form-group'>
                                                {{Form::checkbox('boxflag',null,0,['id'=>'boxflag'])}}
                                                <!--{{Form::label('Value in box')}}-->
                                            </div>
                                        </td>
                                        <td>
                                            <div class='form-group'>
                                                <!--{{Form::label('Label')}}-->
                                                {{Form::text('label',null,['class'=>'form-control-input'])}} @if($errors->has('name'))
                                                <span class='text-danger'>{{ $errors->first('label') }}</span> @endif
                                            </div>
                                        </td>
                                        <td>
                                            <div class='form-group'>
                                                <!--{{Form::label('Tooltips')}}-->
                                                {{Form::text('tooltips',null,['class'=>'form-control-input'])}} @if($errors->has('name'))
                                                <span class='text-danger'>{{ $errors->first('label') }}</span> @endif
                                            </div>
                                        </td>
                                        <td>
                                            <div class='form-group'>
                                              <select class=form-control-select name='sequence' id='sequence'>
                                                    @for ($i = 1; $i
                                                    < 100; $i++) <option value={{$i}}>{{ $i }}</option>
                                                        @endfor </select>

                                            </div>
                                        </td>
                                        <td style='vertical-align:middle;'>
                                            <i aria-hidden='true' class='fa fa-edit' style='color: rgba(0, 0, 255, .7);margin: 0 5px;font-size: 1.1rem;'></i>
                                            <i aria-hidden='true' class='fa fa-trash' style='color: rgba(255, 0, 0, .7);margin: 0 5px;font-size: 1.1rem;'></i>
                                        </td>
                                    </tr>";
        }
    }

    //Edit existing form
    public function EditFormFields(Request $request)
    {
       
        $validator = Validator::make($request->all() , ['listofform' => 'required']);

        if ($validator->fails())
        {
            $errors = $validator->errors();
            $form = FormDetails::pluck('name', 'id');
            return view('admin.editform', compact('form'))->with('errors', $errors);
        }
        $id = $request->post('listofform');
        $values = FormFields::where('formid',$id)->get();
        
        $genericfields = GenericFields::all();
        $formname = FormDetails::where('id', $id)->pluck('name', 'id');
        $table = FormDetails::where('id', $id)->pluck('name');
        $urlsegment = \Request::segment(2);
   
return view('admin.form', compact( 'formname', 'genericfields','values'))
                ->with('urlsegment',$urlsegment);

    }

    public function SaveFields(Request $request)
    {
        print_r($request->all());die;
        try
        {
            // putting some validation rules for User input
            $validator = Validator::make($request->all() , ['fieldname' => 'required',  'label' => 'required', 'sequence' => 'required']);

            if ($validator->fails())
            {
                $errors = $validator->errors();
                $field = MasterField::pluck('name', 'id');
                $formname = FormDetails::pluck('name', 'id');
                $genericfields = GenericFields::all();
                $groupfields = GroupFields::all();
                return view('admin.form', compact('field', 'formname', 'genericfields', 'groupfields'))->with('errors', $errors);
            }
           
            $formid = $request->post('formname');
            $fieldname = $fieldtype = $ttl = $placeholder = $displayvalue = [];
            $fieldname = $request->post('fieldname');

           // $fieldtype = $request->post('fieldtype');
            $ttl = $request->post('tooltips');
            $placeholder = $request->post('placeholder');
            $sequence = $request->post('sequence');
            $valinchr = $request->post('boxflag');
            $label = $request->post('label');
            $subfield = $request->post('subfields');
            $optionoptionsid = $request->post('optionoptionsid');
            $displayvalue = $request->post('displayValue');
            $optionflags = $request->post('optionflags')?$request->post('optionflags'):0;
            $index = 0;
       
            foreach ($fieldname as $value)
            {
                if(isset($value)&&!empty($value)){
                    $valinchr[$index] = isset($valinchr[$index]) ? $valinchr[$index] : 0;
                    if ($valinchr[$index] == 'on') $valinchr[$index] = 1;
                    else $valinchr[$index] = 0;
                    $index++;
                }
            }
     
             foreach ($fieldname as $value)
                {   
                    echo $value;
                }
            $index = 0;
            $rows = [];
    
            if (!empty($fieldname))
            {
                $cnt = count($fieldname);
                
                foreach ($fieldname as $value)
                {   
               
                    if(empty($value) && !empty($displayvalue[$index])){
                    
                        $data = GenericFields::create(['genericfield' => $displayvalue[$index], 'created_at' => now() , 'updated_at' => now() ]);
                        $value = $data->id;
                    }
                    $c = $index+1;
                    $rows[$index] = ['genericid' => $value, 
                                     'sequence' => isset($sequence[$index]) ? $sequence[$index] : null,
                                     'label'=> isset($label[$index]) ? $label[$index] : null,
                                     'placeholder' => isset($placeholder[$index]) ? $placeholder[$index] : null,
                                     'tooltips' => isset($ttl[$index]) ? $ttl[$index] : null,
                                     'created_at' => now() , 'updated_at' => now() ,
                                     'formid' => $formid, 
                                     'optionoptionsid'=>isset($optionoptionsid[$index])?$optionoptionsid[$index]:0,
                                     'optionflags'=>($optionflags[$index + 1]=='on')?1:0,
                                     'subfield' => isset($subfield[$index])?$subfield[$index]: null,
                                     'valinchr' => isset($valinchr[$index]) ? $valinchr[$index]: null
                                    ];
                    $index++;        
                } 
          
               
           }
            
            $formfield = FormFields::insert($rows);
            return redirect('/admin/create-view');
        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }

    }
    //Edit form to save fields of form
    public function EditSaveFields(Request $request){
     
        try{
                // putting some validation rules for User input
            $validator = Validator::make($request->all() , ['fieldname' => 'required',  'label' => 'required', 'sequence' => 'required']);

            if ($validator->fails())
            {
                $errors = $validator->errors();
                $field = MasterField::pluck('name', 'id');
                $formname = FormDetails::pluck('name', 'id');
                $genericfields = GenericFields::all();
                $groupfields = GroupFields::all();
                return view('admin.form', compact('field', 'formname', 'genericfields', 'groupfields'))->with('errors', $errors);
            }
           
            $formid = $request->post('formname');
            $formrecordeds = FormFields::where('formid',$formid)->get();
            
           
            $fieldname = $fieldtype = $ttl = $placeholder = $displayvalue = [];
            $fieldname = $request->post('fieldname');

           // $fieldtype = $request->post('fieldtype');
            $ttl = $request->post('tooltips');
            $placeholder = $request->post('placeholder');
            $sequence = $request->post('sequence');
            $valinchr = $request->post('boxflag');
            $label = $request->post('label');
            $subfield = $request->post('subfields');
            $displayvalue = $request->post('displayValue');
     
            $index = 0;
            foreach ($fieldname as $value)
            {
        $valinchr[$index] = isset($valinchr[$index]) ? $valinchr[$index] : 0;
                if ($valinchr[$index] == 'on') $valinchr[$index] = 1;
                else $valinchr[$index] = 0;
                $index++;
            }
          
            $index = 0;
            $rows = [];
         
            if (!empty($fieldname))
            {
               
                foreach ($fieldname as $value)
                {
                    if(empty($value) && !empty($displayvalue[$index])){
                        $data = GenericFields::create(['genericfield' => $displayvalue[$index], 'created_at' => now() , 'updated_at' => now() ]);
                        $value = $data->id;
                    }
              
                    $rows[$index] = ['genericid' => $value, 'sequence' => isset($sequence[$index]) ? $sequence[$index] : null,'label'=> isset($label[$index]) ? $label[$index] : null, 'placeholder' => isset($placeholder[$index]) ? $placeholder[$index] : null, 'tooltips' => isset($ttl[$index]) ? $ttl[$index] : null, 'created_at' => now() , 'updated_at' => now() ,'formid' => $formid, 'subfield' => isset($subfield[$index])?$subfield[$index] : null, 'valinchr' => isset($valinchr[$index]) ? $valinchr[$index] : null];
                   
                    $index++;
                }
                
                
                $indx =0;
                $fldcount = count($request->post('fieldname'));
                $tblfield = $formrecordeds->count();
                foreach($formrecordeds as $key ) {
                    $id =  $key->id;
                   
                        if(!isset($rows[$indx]) ){
                            FormFields::where('id',$id)->delete();
                        }else{
                            FormFields::where('id', $id)->update($rows[$indx]);
                           
                        }
                         $indx = $indx+1;
                }
                $len = count($rows);
                if($indx < $len){
                    for($k=$indx;$k<$len;$k++){
                       FormFields::insert($rows[$k]); 
                    }
                }
            
                return redirect('/admin/create-view');
               }
        }catch(Exception $e){
            return $e->getMessage();
        }
    }
    
    

    public function ListValue(Request $request)
    {
        $table = FormDetails::find($request->templatename);

        $getcols = 'SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
		WHERE TABLE_NAME = ' . "'" . $table->table . "'";
        $cols = DB::select(DB::raw($getcols));

        $getvalues = "SELECT * FROM  " . " `" . $table->table . "` " . " where 1";

        $records = DB::select(DB::raw($getvalues));

        return view('admin.listvalue', compact('cols', 'records'));
    }

    public function CheckFields()
    {

        $htmllist = FormDetails::pluck('templatename', 'id');
        return view('admin.listfields', compact('htmllist'));
    }

    public function CreateView()
    {

        try
        {
            // $validator = Validator::make([$request->all(), ['name'=>'required']]);
            // if($validator->fails()){
            // 	$errors = $validator->errors();
            // 	return view('admin.createview')->with('errors',$errors);
            // }
            $formname = FormDetails::orderBy('id','DESC')->pluck('name', 'id');
            return view('admin.createview', compact('formname'))->with('message', '');

        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }

    }

    /*** Generate form ***/

    public function GenerateForm(Request $request)
    {
        try
        {
            $formid = $request->get('formname');
            $fields = FormFields::where('formid', $formid)->get();
            $formname = FormDetails::find($request->get('formname'));
            /*** option options **/
            
            $lookup=$luk=""; 
            $opt=$subs=$optvalues=[];$j=0;
            $x = "{";
            
            $subfields=FormFields::select('genericid','subfield')->where('formid',$formid)
                                    ->where('optionflags',1)
                                    ->get();
                                    
            foreach($subfields as $s){
                $optvalues[$s->genericid] = explode("||",$s->subfield);
            }
           
            foreach($optvalues as $key=>$val){
                foreach(FormFields::where('optionoptionsid',$key)->where('formid',$formid)->cursor() as $e){
                    $subs = [];
                    $subs = explode("||",$e->subfield);
                    foreach($subs as $sub)
                    {
	                   $lookup = $lookup."'".$sub."',";                
	                }
	                $opt[$j] = "[".$lookup."],";
	                $opt[$j]= "'".trim($val[$j])."':".$opt[$j];
	                
	                $lookup='';
	                $j++;
                }
                
            }
         
            foreach($opt as $ot){
                $luk = $luk.$ot;
            }
            $luk = "{".$luk."}";
           
           
           
            /*** option options **/
            //form submission route and controller
            $route = '/generate/doc/' . strtolower(preg_replace("/\s/", "-", $formname->name));
               
            $controller = 'ToolBuilderController@DynamicFormData';
          
            $view = preg_replace("/\s/", "_", $formname->name);
            
            FormDetails::where('id', $formid)->update(['routes' => $route, 'controllers' => $controller, 'view' => strtolower($view) , 'table' => strtolower($view) ]);
         
            //form create crossponding tables
            $col = '';
            $tablename = strtolower(preg_replace("/\s/", "_", $formname->name));
            $fieldquery = 'SELECT generic_fields.genericfield,form_fields.optionoptionsid,form_fields.optionflags,form_fields.subfield,form_fields.sequence,form_fields.label,form_fields.placeholder,form_fields.tooltips FROM `form_fields` right join `generic_fields` on form_fields.genericid = generic_fields.id where formid='.$formid;
            $data = DB::select($fieldquery);
            
            foreach ($data as $field)
            {
                 
                $col = $col . $field->genericfield . ' VARCHAR(250) NOT NULL,';
            }
         
            if (!Schema::hasTable($tablename))
            {

                $sql = 'CREATE TABLE ' . $tablename . '(id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,' . $col . 'reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)';
                DB::statement($sql);
                $fields = $data;
                $html = view('dynamicform')->with(['fields'=>$fields])->with(['route' => $route, 'opt'=>$luk])->render();
                File::put(resource_path('views') . "/form/" . $tablename . '.blade.php', $html);
                $formname = FormDetails::pluck('name', 'id');
                return view('admin.createview', compact('formname'))->with('message', 'Form created successfully.');
            }
            elseif (Schema::hasTable($tablename))
            {
                //get all columnns of table
                $columns = Schema::getColumnListing($tablename);
                //if deleted the fields
                if(count($fields)<count($columns))
                   {
                        $dropfield = $dropcols = [];
                        $cols = "";
                        $sql ="SELECT generic_fields.genericfield as generic FROM `form_fields` right join `generic_fields` on form_fields.genericid = generic_fields.id where formid=".$formid;
                        $fields = DB::select($sql);
                        $incr = 0;
                        foreach($fields as $field){
                            $dropfield[$incr]= $field->generic;
                            $incr++;
                        }
                        
                        $dropcols = array_diff($columns, $dropfield);
                        foreach($dropcols as $dropcol){
                                if($dropcol !='id')                       
                                $cols = $cols."drop ".$dropcol.",";
                        }
                            
                        //Alter existing table
                        $sql = ' ALTER TABLE ' . strtolower($tablename)." ".
                        rtrim($cols,",");
                          
                        DB::statement($sql);
                        $html = view('dynamicform')->with(['fields'=>$data])
                             ->with(['route' => $route])->render();
                      
                   }else{
                            $str ="";
                            foreach($columns as $col){
                              $str = $str."'".$col."',";
                            }
                            $str = rtrim($str,",");
                            $sql ="SELECT generic_fields.genericfield FROM `form_fields` right join `generic_fields` on form_fields.genericid = generic_fields.id where formid=".$formid." and generic_fields.genericfield not in (".ltrim($str, ',').")";
                            $fields = DB::select($sql);
                            $cols = '';
                            foreach($fields as $field)
                            {
                                $cols = $cols . ' ADD ' . $field->genericfield . ' VARCHAR(250) NOT NULL,';
                            }
                            $cols = rtrim($cols, ",");
                            //Alter existing table
                            $sql = ' ALTER TABLE ' . strtolower($tablename) . $cols;
                            DB::statement($sql);
                           
                            $html = view('dynamicform')->with(['fields'=>$data])
                             ->with(['route' => $route])->render();
                   }    
             
                File::put(resource_path('views') . "/form/" . $tablename . '.blade.php', $html);
                $formname = FormDetails::pluck('name', 'id');
                return view('admin.createview', compact('formname'))->with('message', 'Modify view ');
            }
            else
            {
                $formname = FormDetails::pluck('name', 'id');
                return view('admin.createview', compact('formname'))->with('message', 'View already created.');

            }
            //return view('dynamicform',compact('fields'))->with(['route'=>$route]);
            
        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }
    }

    //Create  new template
    public function CreateTemplate()
    {

        try
        {

            $formname = FormDetails::pluck('name', 'id');
            return view('admin.createtemplate', compact('formname'))->with('message', '');

        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }

    }

    public function TemplateEditor(Request $request)
    {

        try
        {
            $fail = null;
            $formname = $request->get('formname');
            $templatename = FormDetails::where('id', $formname)->get();
            foreach ($templatename as $value)
            {
                $name = $value->name;
            }
            FormDetails::where('id', $formname)->update(['templatename' => $name]);
            
            $sql = 'select form_fields.label as label,generic_fields.genericfield as genericone 
                    from form_fields join generic_fields
                    on form_fields.genericid = generic_fields.id where form_fields.formid='.$formname;
            $fielddetails = DB::table('form_fields')
                ->join('generic_fields','form_fields.genericid','=','generic_fields.id')
                ->where('form_fields.formid','=',$formname)
                ->select('form_fields.label as label','generic_fields.genericfield as genericfield')
                ->get();
               
            $segment = $request->get('segment');

            //Create new template crossponding to new form
            if ($segment != 'edit')
            {
                return view('admin.templateeditor')->with(['fail' => $fail, 'templatename' => $name, 'txt' => null, 'fielddetails' => $fielddetails, 'segment' => $segment]);
            }
            if ($segment == 'edit')
            {
                foreach ($templatename as $record)
                {
                    $filename = $record->filename;
                }
                $filename = storage_path('app/template/') . $filename;

                $txt = $this->DocxRead($filename);
                $txt = htmlspecialchars_decode(stripslashes($txt));
                return view('admin.templateeditor')->with(['fail' => $fail, 
                                                            'templatename' => $name, 
                                                            'txt' => $txt, 
                                                            'fielddetails'=>$fielddetails,
                                                            'segment' => $segment]);

            }

        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }
    }

    public function SaveTemplate(Request $request)
    {

        $validator = Validator::make($request->all() , ['templatecontent' => 'required']);

        if ($validator->fails())
        {
            return view('admin.templateeditor')
                ->with('fail', 'Template data is not fill');
        }

        $phpWord = new \PhpOffice\PhpWord\PhpWord();
        \PhpOffice\PhpWord\Settings::setOutputEscapingEnabled(true);
        $section = $phpWord->addSection();
        $templatetxt = $request->post('templatecontent');
        //echo $templatetxt; die;
        $section->addText($templatetxt);
        // $section->addText(str_replace("&nbsp;", '', strip_tags($templatetxt)));
        $objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
        //$filename = $request->post('filename');
        $filename = request()->segment(count(request()
            ->segments()));
        $path = storage_path() . "/app/template/" . $filename . '.docx';
        $objWriter->save($path);
        $templatename = request()->segment(count(request()
            ->segments()));

        $id = FormDetails::where('name', $templatename)->pluck('id');

        $savedfile = FormDetails::where('id', $id[0])->update(['filename' => $filename . ".docx", 'filepath' => $path]);

        // $fp = (file_exists($path))? fopen($path, "a+") : fopen($path, "w+");
        // $editorCode =$request->post('templatecontent');
        // fwrite($fp, $editorCode);
        // fclose($fp);
        $formname = FormDetails::pluck('name', 'id');
        $segment = $request->post('segment');

        if ($segment == '/')
        {
            return view('admin.createtemplate', compact('formname'))->with('message', 'Template File Saved Successfully');
        }
        else
        {
            return view('admin.edittemplate', compact('formname'))
                ->with('segment', $segment)->with('message', 'Template File Saved Successfully');
        }

    }

    public function TemplateEdit(Request $request)
    {
        try
        {
            $fail = null;
            $formname = $request->get('formname');

            $templatename = FormDetails::where('id', $formname)->get();
            foreach ($templatename as $value)
            {
                $name = $value->name;
            }
            $editcontent = file_get_contents(resource_path() . '/views/template/' . $name . '.blade.php');

            return view('admin.editmodetemplateeditor')->with(['fail' => $fail, 'templatename' => $name, 'editcontent' => $editcontent]);
        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }
    }

    public function UploadTemplate(Request $request)
    {
        try
        {
            $fail = null;
            $message = null;
            $formname = $request->get('formname');
            $templatename = FormDetails::where('id', $formname)->get();
            foreach ($templatename as $value)
            {
                $name = $value->name;
            }
            FormDetails::where('id', $formname)->update(['templatename' => $name]);
            $fields = Form::where('formid', $formname)->pluck('fieldname');
            return view('admin.uploadtemplate')
                ->with(['fail' => $fail, 'templatename' => $name, 'fieldsname' => $fields, 'message' => $message]);
        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }

    }

    public function TemplateFileUpload(Request $request)
    {

        try
        {
            $validator = Validator::make($request->all() , ['templatefile' => 'required|file|max:5000'

            ]);
            $templatename = request()->segment(count(request()
                ->segments()));
            $id = FormDetails::where('name', $templatename)->pluck('id');

            $fields = Form::where('formid', $id[0])->pluck('fieldname');

            if ($validator->fails())
            {

                $errors = $validator->errors();
                print_r($errors);
                return view('admin.uploadtemplate')->with(['errors' => $errors, 'message' => 'Error  in upload', 'templatename' => $templatename, 'fieldsname' => $fields]);
            }

            //if(hasFile('templatefile')){
            $file = $request->file('templatefile');
            $originalname = $file->getClientOriginalName();
            $extension = $file->getClientOriginalExtension();
            $path = $file->storeAs("/template", $originalname);
            FormDetails::where('id', $id[0])->update(['filename' => $originalname, 'filepath' => storage_path() . '/template/' . $originalname

            ]);

            return view('admin.uploadtemplate')->with(['message' => 'File uploaded Successfully', 'templatename' => $templatename, 'fieldsname' => $fields]);

        }
        catch(\Exception $e)
        {

            return $e->getMessage();
        }
    }

    public function GetOptions($formid)
    {
        try
        {

            $optiongroupfield = Form::where('groupfields', '1')->where('formid', $formid)->pluck('label', 'id');
            return Response::json(['data' => $optiongroupfield, 'status' => 200]);
        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }
    }
    //After deletion of fields in edit form box
    public function ViewAfterdeletefields($id)
    {

        $formname = FormDetails::where('id', $id)->pluck('name', 'id');

        $field = MasterField::pluck('name', 'id');
        $optiongroupfield = Form::where('groupfields', '1')->where('formid', $id)->pluck('label', 'id');
        $attributes = Form::where('formid', $id)->get();
        $table = FormDetails::where('id', $id)->pluck('name');
        $urlsegment = \Request::segment(2);

        return view('admin.form', compact('field', 'formname', 'optiongroupfield', 'attributes'))->with('tablename', $table[0])->with('formid', $id)->with('urlsegment', $urlsegment);
    }
    //Delete fields from form
    public function DeleteFields(Request $request)
    {
        try
        {
            $tablename = last(request()->segments());
            $formid = request()->segment(4);
            $fieldcheckbox = $request->get('fieldcheckbox');
            $cols = '';

            foreach ($fieldcheckbox as $fieldtodelete)
            {
                $cols = $cols . ' drop column ' . $fieldtodelete . ",";

            }
            $cols = rtrim(",", $cols);
            $sql = 'alter table ' . strtolower($tablename) . '' . $cols;

            DB::statement($sql);

            foreach ($fieldcheckbox as $fieldtodelete)
            {

                Form::where('formid', $formid)->where('fieldname', $fieldtodelete)->delete();
            }
            $fields = Form::where('formid', $formid)->get();
            $formname = FormDetails::find($formid);
            $route = '/generate/doc/' . strtolower(preg_replace("/\s/", "-", $formname->name));

            $html = view('dynamicform', compact('fields'))->with(['route' => $route])->render();
            File::put(resource_path('views') . "/form/" . $tablename . '.blade.php', $html);
            return Redirect::to('/admin/edit-application-form/' . $formid);
            //$this->ViewAfterdeletefields($formid);
            
        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }
    }

    //list all the forms for operations on it.
    public function ListForms()
    {
        try
        {
            $listforms = FormDetails::orderBy('name', 'ASC')->paginate(5);
            $message = null;
            return view('admin.listforms', compact('listforms'))->with('message', $message);

        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }

    }
    //Delete form
    public function DeleteForm($id)
    {
        try
        {
            $form = FormDetails::findorfail($id);
            $filename = isset($form->filename) ? $form->filename : null;
            if (!empty($filename))
            {
                File::delete(storage_path() . '/' . $form->filename);
            }
            FormDetails::where('id', $id)->delete();
            $listforms = FormDetails::orderBy('name', 'ASC')->paginate(10);
            return redirect()
                ->back()
                ->with('message', 'Record deleted successfully');
        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }

    }
    //Fetch the edit template form
    public function EditTemplate()
    {
        try
        {
            $segment = \Request::segment(2);
            $formname = FormDetails::pluck('name', 'id');

            return view('admin.edittemplate', compact('formname'))->with('segment', $segment)->with('message', '');

        }
        catch(\Exception $e)
        {
            return $e->getMessage();
        }

    }

    public function DocxRead($filename)
    {
        $striped_content = '';
        $content = '';

        $zip = zip_open($filename);

        if (!$zip || is_numeric($zip)) return false;

        while ($zip_entry = zip_read($zip))
        {

            if (zip_entry_open($zip, $zip_entry) == false) continue;

            if (zip_entry_name($zip_entry) != "word/document.xml") continue;

            $content .= zip_entry_read($zip_entry, zip_entry_filesize($zip_entry));

            zip_entry_close($zip_entry);
        } // end while
        zip_close($zip);

        $content = str_replace('</w:r></w:p></w:tc><w:tc>', " ", $content);
        $content = str_replace('</w:r></w:p>', "\r\n", $content);
        $striped_content = strip_tags($content);

        return $striped_content;

    }

}

