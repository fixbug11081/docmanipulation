<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GenericFields extends Model
{
    protected $table = 'generic_fields';
    protected $fillable = ['genericfield','created_at','updated_at'];
}
