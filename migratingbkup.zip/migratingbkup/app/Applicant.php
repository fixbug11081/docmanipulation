<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Applicant extends Model
{
    protected $table='applicants';
    protected $fillable = ['name','gender','gaurdian','address','dob','updated_at','created_at'];
}
