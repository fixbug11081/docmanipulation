<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MetaForm extends Model
{
    //
    protected $table = 'meta_forms';
    protected $fillable = ['fieldname','fieldtype','method','label','sequence','formid','created_at','updated_at'];
}
