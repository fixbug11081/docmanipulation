<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MasterField extends Model
{
    protected $table = 'master_fields';
    protected $fillable = ['name'];
}
