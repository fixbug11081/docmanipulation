<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GroupFields extends Model
{
    protected $table = 'group_fields';
    protected $fillable = ['genericoneid','subfield','created_at','updated_at'];
}
