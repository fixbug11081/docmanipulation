<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FormFields extends Model
{
    protected $table = 'form_fields';
    protected $fillable = ['genericid','sequence','fieldtype','label','placeholder','tooltips','created_at','updated_at', 'formid',  'valinchr'];
}
