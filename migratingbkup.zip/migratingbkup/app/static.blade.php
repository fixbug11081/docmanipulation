	<!DOCTYPE>
	<html>
	<head>

	</head>
	<title></title>
	<body>
    <a href="{{ URL::to('/customers/pdf') }}">Export PDF</a>
    		
	<center>
		<br><br><br><br>
	APPLICATION FORM FOR FINANCIAL ASSISTANCE SCHEME FOR
	EDUCATED<br>
	UNEMPLOYED PERSONS<br><br>



	<table>

	<tr>
		<td >1. </td>
		<td>Name of tde Applicant (in block letters)</td>
		<td align="right">ajeet</td>
	</tr>
	<tr>
		<td>2. </td>
		<td >Sex Male / Female</td>
		<td align="right">sdsf</td>
	</tr>
	<tr>
		<td>3. </td>
		<td>Fatder’s/Husband’s name</td>
		<td align="right">sdfsdf</td>
	</tr>
	<tr>
		<td>4. </td>
		<td>address for correspondence<br>
		Permanent address <br>
		Whetder resident certificate enclosed<br>
	for a minimum period of 3 years where<br>
	loan is going to be availed</td>
		<td align="right">sfsdfsdf</td>
	</tr>
	<tr>
		<td >5. </td>
		<td >Date of birtd and age </td>
		<td align="right">sdfsdfsf</td>
	</tr>
	</table>

	</center>


	</body>
	</html>