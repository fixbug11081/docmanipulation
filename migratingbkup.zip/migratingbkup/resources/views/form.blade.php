<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- SEO Meta Tags -->
	<meta name="description" content="Create a stylish landing page for your business startup and get leads for the offered services with this HTML landing page template.">
	<meta name="author" content="Inovatik">

	<!-- OG Meta Tags to improve the way the post looks when you share the page on LinkedIn, Facebook, Google+ -->
	<meta property="og:site_name" content="" /> <!-- website name -->
	<meta property="og:site" content="" /> <!-- website link -->
	<meta property="og:title" content=""/> <!-- title shown in the actual shared post -->
	<meta property="og:description" content="" /> <!-- description shown in the actual shared post -->
	<meta property="og:image" content="" /> <!-- image link, make sure it's jpg -->
	<meta property="og:url" content="" /> <!-- where do you want your post to link to -->
	<meta property="og:type" content="article" />

	<!-- Website Title -->
	<title>Docmaster - Repo builder </title>

	<!-- Styles -->
	<link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,600,700,700i&amp;subset=latin-ext" rel="stylesheet">
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/fontawesome-all.css" rel="stylesheet">
	<link href="css/swiper.css" rel="stylesheet">
	<link href="css/magnific-popup.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">

	<!-- Favicon  -->
	<link rel="icon" href="images/favicon.png">
</head>
<body data-spy="scroll" data-target=".fixed-top">

	<!-- Preloader -->

	<!-- end of preloader -->

@include('navbar')

	<div id="" class="grayFormSec">
		<div class="container"> 
			<div class="box">
				<h2 class="mb-3">Document Form</h2>
				<div class="form-group  appForm">

					@if ($message = Session::get('fail'))
					<div class="alert alert-success">
						<p>{{ $message }}</p>
					</div>
					@endif
					@if (count($errors) > 0)
					<div class="alert alert-danger">

						<ul>
							@foreach ($errors->all() as $error)
							<li><font color=red>{{ $error }}</fonr></li>
								@endforeach
							</ul>
						</div>

						@endif

						@if ($message = Session::get('success'))
						<div class="alert alert-success">
							<p>{{ $message }}</p>
						</div>
						@endif

						{{Form::open([ "url"=>"/save/fields","method"=>"POST", "class"=>"build-form"])}}
						<div class="form-group">
							{{Form::label('Form name')}}
							{{Form::select('formname', $formname,null, ['class'=>'form-control-input'])}}
						</div>
						<div class="form-group">
							{{Form::label('Field name')}}
							{{Form::text('fieldname',null,['class'=>'form-control-input'])}}
							@if($errors->has('name'))
							<span class="text-danger">{{ $errors->first('name') }}</span>
							@endif
						</div>
						<div class="form-group">
							{{Form::label('Field Type')}}
							{{Form::select('fieldtype', $field, null,['class'=>'form-control-input'])}}
						</div>
				    	<div class="form-group">
							{{Form::label('Method')}}
							{{Form::text('method',null,['class'=>'form-control-input'])}}
							@if($errors->has('name'))
							<span class="text-danger">{{ $errors->first('method') }}</span>
							@endif
						</div> 
						<div class="form-group">
							{{Form::label('Label')}}
				{{Form::text('label',null,['class'=>'form-control-input'])}}
							@if($errors->has('name'))
							<span class="text-danger">{{ $errors->first('label') }}</span>
							@endif
						</div>
						<div class="form-group">
							{{Form::label('sequence')}}
							{{Form::text('sequence',null,['class'=>'form-control-input'])}}
							@if($errors->has('name'))
							<span class="text-danger">{{ $errors->first('sequence') }}</span>
							@endif
						</div>


						<div class="form-group">
							{{Form::submit('submit', ['name'=>'submit', 'class'=>'submit btn-solid-lg btn' ])}}
							{{Form::button('refresh', ['name'=>'refresh', 'class'=>'refresh btn-solid-lg btn' ])}}
							{{Form::close()}}
						</div> 
					</div>   

				</div>
			</div>
		</div> 

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

		<script type="text/javascript">

			$(document).ready(function(){
				$('.refresh').click(function(e){

					$('.build-form').trigger('reset');
				});

		  
		   	});
		   </script>
		   <!-- Scripts -->
		   <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
		   <script src="js/popper.min.js"></script> <!-- Popper tooltip library for Bootstrap -->
		   <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
		   <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
		   <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
		   <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
		   <script src="js/validator.min.js"></script> <!-- Validator.js - Bootstrap plugin that validates forms -->
		   <script src="js/scripts.js"></script> <!-- Custom scripts -->


		</body>
		</html>