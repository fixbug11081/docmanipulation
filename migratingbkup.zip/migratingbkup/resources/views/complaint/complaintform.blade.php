<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.css">

    <title>Complaint Form</title>
<style>
    .container {margin:0 auto;color:#626262;font:400 1rem/1.5rem "Raleway", sans-serif;}
  .form-group {
    position: relative;
    margin-bottom: 1.25rem;
}
  .form-control-input, .form-control-select {
    display: block;
    width: 100%;
    padding-top: 1rem;
    padding-bottom: 1rem;
    padding-left: 1.3125rem;
    border: 1px solid #c4d8dc;
    border-radius: 0.25rem;
    background-color: #fff;
    color: #626262;
    font: 400 0.875rem/1.875rem "Raleway", sans-serif;
    transition: all 0.2s;
    /* -webkit-appearance: none; */
}
form .form-control-input {
    padding-top: 0.7rem;
    padding-bottom: 0.7rem;
    height:auto;
  }
  .form-control-textarea {
    display: block;
    width: 100%;
    padding-top: 1rem;
    padding-bottom: 1rem;
    padding-left: 1.3125rem;
    border: 1px solid #c4d8dc;
    border-radius: 0.25rem;
    background-color: #fff;
    color: #626262;
    font: 400 0.875rem/1.875rem "Raleway", sans-serif;
    transition: all 0.2s;
  }
.form-control-input:hover, .form-control-select:hover, .form-control-textarea:hover {
    border: 1px solid #a1a1a1;
}
.form-control-input:focus, .form-control-select:focus, .form-control-textarea:focus {
    border: 1px solid #a1a1a1;
    outline: none;
}
form .btn-solid-lg, .modal .modal-footer .btn-solid-lg {    
  display: inline-block;
    padding: 1.375rem 2.625rem 1.375rem 2.625rem;
    border-radius: 2rem;
    color: #fff;
    font: 700 .8rem/0 "Raleway", sans-serif;
    text-decoration: none;
    transition: all 0.2s;
    margin-left:10px;
    text-transform:uppercase;
  }
  .btn-primary {      
    border: 0.125rem solid #00BFD8;
    background-color: #00BFD8;
    }    
    form .btn-dark, .modal .btn-dark {      
    border: 0.125rem solid #343A40;
    background-color: #343A40;
    }
    form .btn-primary:hover, .modal .btn-primary:hover {    
    border: 0.125rem solid #00BFD8;  
    background-color: #fff;
    color: #00BFD8;
    }    
    form .btn-dark:hover, .modal .btn-dark:hover {    
    border: 0.125rem solid #343A40;  
    background-color: #fff;
    color: #343A40;
    }
    label {
      font: 400 0.875rem/1.875rem "Raleway", sans-serif;
      color:#626262;
      margin-bottom: 0rem;
    }
    .modal .input-group-append .input-group-text {background-color:rgba(0, 0, 0, 0);}
    .input-group-text a {color:#00BFD8;text-decoration:none;}
    .input-group .form-control-input {border-right-width: 0;}
    .modal .a-link {color:#00BFD8;text-decoration:none;}
    .modal .a-link:hover {color:#00BFD8;text-decoration:underline;}
    
.navbar.navbar-custom {background-color:#fff;box-shadow:0 0.0625rem 0.375rem 0 rgba(0, 0, 0, 0.1);padding:0.5rem 5rem 0.5rem 5rem;}
.complaint-content {padding-top: 120px;}
form {width:100%;}
</style>


    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="Repo Builder - Create application hasless filled form.">
    <meta name="author" content="Inovatik">

    <!-- OG Meta Tags to improve the way the post looks when you share the page on LinkedIn, Facebook, Google+ -->
  <meta property="og:site_name" content="" /> <!-- website name -->
  <meta property="og:site" content="" /> <!-- website link -->
  <meta property="og:title" content=""/> <!-- title shown in the actual shared post -->
  <meta property="og:description" content="" /> <!-- description shown in the actual shared post -->
  <meta property="og:image" content="" /> <!-- image link, make sure it's jpg -->
  <meta property="og:url" content="" /> <!-- where do you want your post to link to -->
  <meta property="og:type" content="article" />

    <!-- Website Title -->
    <title>Repo Builder - Create Application hasless Filled Form</title>
    
    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,600,700,700i&amp;subset=latin-ext" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="css/swiper.css" rel="stylesheet">
  <link href="css/magnific-popup.css" rel="stylesheet">
  <link href="css/styles.css" rel="stylesheet">
  
  <!-- Favicon  -->
    <link rel="icon" href="images/favicon.png">

  </head>

<body data-spy="scroll" data-target=".fixed-top">
     <!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
	<!-- Text Logo - Use this if you don't have a graphic logo -->
	<!-- <a class="navbar-brand logo-text page-scroll" href="index.html">Evolo</a> -->

	<!-- Image Logo -->
	<!--<a class="navbar-brand logo-image" href="/">-->
	   <a href= "/" style="text-decoration:none">
	       <h1> DocMaster</h1>
	   </a>    
	    <!--<img src="images/logo.svg" alt="alternative">-->
	   <!--</a>-->

	<div class="collapse navbar-collapse" id="navbarsExampleDefault">
		<ul class="navbar-nav ml-auto">
		    <li class="nav-item">
				<a class="nav-link page-scroll" href="/login">Login</a>
			</li>
			<li class="nav-item">
				<a class="nav-link page-scroll" href="/faq" target="_blank">FAQ</a>
			</li>
			<li class="nav-item">
				<a class="nav-link page-scroll" href="/complaint" target="_blank">Complaint</a>
			</li>
		</ul>
		
	</div>
</nav> <!-- end of navbar -->
	<!-- end of navigation -->
     
     <section id="complaint" class="complaint mb-5">
        <div class="complaint-content">
    <div class="container">
                <div class="row">
    <h3 class="m-auto pb-4">Complaint Box</h3>
    <form method="POST" action="" accept-charset="UTF-8" class="">    
<div class="row">
  <div class="col">
    <div class="form-group custom-form-inline">
    <label for="state" class="sr-only">State</label>
    <select class="form-control-select" id="state">
      <option>State</option>
      <option>State1</option>
    </select>
  </div>
</div>
<div class="col">
  <div class="form-group custom-form-inline">
  <label for="city" class="sr-only">City</label>
  <select class="form-control-select" id="city">
    <option>City</option>
    <option>City1</option>
  </select>
</div>
</div>
<div class="col">
  <div class="form-group custom-form-inline">
  <label for="district" class="sr-only">District</label>
  <select class="form-control-select" id="district">
    <option>District</option>
    <option>District1</option>
  </select>
</div>
</div>
</div>
<div class="row">
  <div class="form-group col-sm-6">
    <div class="custom-radio custom-control-inline">
      <label class="" for="org">Type of Organisation</label>
    </div>
    <div class="custom-control custom-radio custom-control-inline">
      <input type="radio" id="customRadioInline1" name="customRadioInline1" class="custom-control-input">
      <label class="custom-control-label" for="customRadioInline1">Public</label>
    </div>
    <div class="custom-control custom-radio custom-control-inline">
      <input type="radio" id="customRadioInline2" name="customRadioInline1" class="custom-control-input">
      <label class="custom-control-label" for="customRadioInline2">Private</label>
    </div>
  </div>
</div>
<div class="row">
  <div class="col">
    <div class="form-group custom-form-inline">
    <label for="organisation" class="sr-only">Organisation Name</label>
    <select class="form-control-select" id="organisation">
      <option>Organisation Name</option>
      <option>Organisation Name1</option>
    </select>
  </div>
</div>
<div class="col">
  <div class="form-group custom-form-inline">
  <label for="department" class="sr-only">Department</label>
  <select class="form-control-select" id="department">
    <option>Department</option>
    <option>Department1</option>
  </select>
</div>
</div>
</div>
<div class="row">
  <div class="col">
    <div class="form-group custom-form-inline">
    <label for="complaint" class="sr-only">Type of Complaint</label>
    <select class="form-control-select" id="complaint">
      <option>Type of Complaint</option>
      <option>Type of Complaint1</option>
    </select>
  </div>
</div>
<div class="col">
  <div class="form-group custom-form-inline">
  <label for="authority" class="sr-only">Concerned Authority</label>
  <select class="form-control-select" id="authority">
    <option>Concerned Authority</option>
    <option>Concerned Authority1</option>
  </select>
</div>
</div>
</div>
<div class="row">
  <div class="col">
    <div class="form-group custom-form-inline">
    <label for="subject" class="sr-only">Subject</label>
    <input type="text" class="form-control-input" placeholder="Subject" />
  </div>
</div>
</div>
<div class="row">
  <div class="col">
<div class="form-group">
  <label for="complaint-detail" class="sr-only">Write your Complaint</label>
  <textarea class="form-control-textarea" id="complaint-detail" rows="3" placeholder="Write your Complaint"></textarea>
</div>
</div>
</div>
<div class="row">
  <div class="col-md-6 offset-sm-6 text-right">        
<button type="button" class="btn btn-dark btn-solid-lg">Cancel</button>
  <button type="button" class="btn btn-primary btn-solid-lg">Reset</button>
<button type="button" class="btn btn-primary btn-solid-lg" data-toggle="modal" data-target="#signup">Submit</button>
  </div>
</div>
</form>
</div>
</div>
</div>
</section>

<!-- Modal -->
<div class="modal fade" id="signup" tabindex="-1" role="dialog" aria-labelledby="signupTitle" aria-hidden="true" data-backdrop="static">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-center" id="signupTitle">Register Now</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" action="/signup" accept-charset="UTF-8" class="">  
          <div class="form-group custom-form-inline">
            <label for="name" class="sr-only">Full Name</label>
            <input type="text"  name="name" class="form-control-input" placeholder="Full Name"  />
          </div>
          <div class="input-group mb-3">
            <input type="email"  name="email" class="form-control form-control-input" placeholder="Email ID" aria-describedby="basic-addon2">
            <div class="input-group-append">
              <span class="input-group-text" id="basic-addon2"><a href="" class="a-link">Send Verification Code</a></span>
            </div>
          </div>

          <div class="input-group mb-3">
            <input type="tel" name="mobilenumber"class="form-control form-control-input" placeholder="Mobile No." aria-describedby="basic-addon2">
            <div class="input-group-append">
              <span class="input-group-text" id="basic-addon2"><a href="" class="a-link">Send Verification Code</a></span>
            </div>
          </div>
          <div class="form-group custom-form-inline">
            <label for="otp" class="sr-only">OTP</label>
            <input type="text"  name="otp" class="form-control-input" placeholder="OTP" />
          </div>
          </form>
      </div>
      <div class="modal-footer">
        <a href="" class="a-link float-left">Already Registered</a>
        <button type="button" class="btn btn-dark btn-solid-lg">Cancel</button>
        <button type="button" class="btn btn-primary btn-solid-lg">Submit</button>
      </div>
    </div>
  </div>
</div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/popper.min.js"></script> <!-- Popper tooltip library for Bootstrap -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
    <script src="js/validator.min.js"></script> <!-- Validator.js - Bootstrap plugin that validates forms -->
    <script src="js/scripts.js"></script> <!-- Custom scripts -->
  </body>
</html>