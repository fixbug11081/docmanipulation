<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- SEO Meta Tags -->
	<meta name="description" content="Create a stylish landing page for your business startup and get leads for the offered services with this HTML landing page template.">
	<meta name="author" content="Inovatik">

	<!-- OG Meta Tags to improve the way the post looks when you share the page on LinkedIn, Facebook, Google+ -->
	<meta property="og:site_name" content="" /> <!-- website name -->
	<meta property="og:site" content="" /> <!-- website link -->
	<meta property="og:title" content=""/> <!-- title shown in the actual shared post -->
	<meta property="og:description" content="" /> <!-- description shown in the actual shared post -->
	<meta property="og:image" content="" /> <!-- image link, make sure it's jpg -->
	<meta property="og:url" content="" /> <!-- where do you want your post to link to -->
	<meta property="og:type" content="article" />

	<!-- Website Title -->
	<title>Docmaster-Repo builder to build form amd template</title>

	<!-- Styles -->
	<link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,600,700,700i&amp;subset=latin-ext" rel="stylesheet">
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/fontawesome-all.css" rel="stylesheet">
	<link href="css/swiper.css" rel="stylesheet">
	<link href="css/magnific-popup.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">

	<!-- Favicon  -->
	<link rel="icon" href="images/favicon.png">
</head>
<body data-spy="scroll" data-target=".fixed-top">

	<!-- Preloader -->
	
	<!-- end of preloader -->


	<!-- Navigation -->
	<!-- Navigation -->

<nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
	<!-- Text Logo - Use this if you don't have a graphic logo -->
	<!-- <a class="navbar-brand logo-text page-scroll" href="index.html">Evolo</a> -->

	<!-- Image Logo -->
	<!--<a class="navbar-brand logo-image" href="/">-->
	   <a href="/" style="text-decoration:none;">
	       <h1>DocMaster</h1>
	   </a>    
	    <!--<img src="images/logo.svg" alt="alternative">-->
	   <!--</a>-->

	<div class="collapse navbar-collapse" id="navbarsExampleDefault">
		<ul class="navbar-nav ml-auto">
		    <li class="nav-item">
				<a class="nav-link page-scroll" href="/login">Login</a>
			</li>
			<li class="nav-item">
				<a class="nav-link page-scroll" href="/faq" target="_blank">FAQ</a>
			</li>
			<li class="nav-item" >
				<a class="nav-link page-scroll" href="/complaint-home" >Complaint</a>
			</li>	
		
           	
		</ul>
		
	</div>
</nav> <!-- end of navbar -->
	<!-- end of navigation -->	<!-- end of navbar -->
	<!-- end of navigation -->

	<div id="" class="grayFormSec">
		<div class="container"> 
			<div class="box">
				<h2 class="mb-3">Form</h2>
				<form method="POST" action="http://docmaster.webappmate.in/generate/doc/electricityform" accept-charset="UTF-8" class="build-form"><input name="_token" type="hidden" value="YDe6NAcUBcloc5IANuROii0TT90KQmV8kY1KQInD">
														<div class="form-group custom-form-inline">
					<label for="Request No.">Request No.</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Request No." name="requestno" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Name">Name</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Name" name="name" type="text">
				   
					</div>
																																																																																											<div class="form-group custom-form-inline">
					<label for="Date of Birth">Date Of Birth</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Date of Birth" name="dob" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Gaurdian name">Gaurdian Name</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Gaurdian name" name="gaurdianname" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Mother Name">Mother Name</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Mother Name" name="mothername" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Communication Address">Communication Address</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Communication Address" name="chouseno" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Building Name">Building Name</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Building Name" name="buildingname" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Street">Street</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Street" name="street" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Area">Area</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Area" name="area" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Pincode">Pincode</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Pincode" name="pin" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="LandMark">LandMark</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="LandMark" name="landmark" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Mobile">Mobile</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Mobile" name="mobile" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Landline">Landline</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Landline" name="landline" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Email">Email</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Email" name="email" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Permanent House no.">Permanent House No.</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Permanent House no." name="phouseno" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Permanent Building name">Permanent Building Name</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Permanent Building name" name="pbuildingname" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Permanent Street">Permanent Street</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Permanent Street" name="pstreet" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Area">Area</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Area" name="parea" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Landmark">Landmark</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Landmark" name="plandmark" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Permanent Mobile">Permanent Mobile</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Permanent Mobile" name="pmobile" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Permanent Email">Permanent Email</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Permanent Email" name="pemail" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Domestic Category">Domestic Category</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Domestic Category" name="dcat" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="No domestic categroy">No Domestic Categroy</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="No domestic categroy" name="nodomestic" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Industrial">Industrial</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Industrial" name="industrial" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Agricultural">Agricultural</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Agricultural" name="agricultural" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Mushroom">Mushroom</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Mushroom" name="mushroom" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Public lighting">Public Lighting</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Public lighting" name="publiclighting" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="DJb">DJb</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="DJb" name="djb" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="dial">Dial</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="dial" name="dial" type="text" id="dial">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Railway Traction">Railway Traction</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Railway Traction" name="railwaytraction" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Dmrc">Dmrc</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Dmrc" name="dmrc" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Advertising">Advertising</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Advertising" name="advertising" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="Temporary Supply">Temporary Supply</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Temporary Supply" name="tempsupply" type="text">
				   
					</div>
																			<div class="form-group custom-form-inline">
					<label for="E-Richshaw">E-Richshaw</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="E-Richshaw" name="erickshaw" type="text">
				   
					</div>
																																														<div class="form-group custom-form-inline">
					<label for="Exist Connection">Exist Connection</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Exist Connection" name="existconnection" type="text">
				   
					</div>
																																																																																																																																																																																																																<div class="form-group custom-form-inline">
					<label for="Valid till">Valid Till</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Valid till" name="validtill" type="text">
				   
					</div>
																																														<div class="form-group custom-form-inline">
					<label for="Date">Date</label>
					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
					<input class="form-control-input" placeholder="Date" name="date" type="text">
				   
					</div>
													
				    				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     					<label for="Title">Title</label>
    					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
    					        					    <div class="form-group">
    						    						    					        						    					        						    					        						            					
            					<input id="&#039;mr&#039;" name="mr" type="checkbox">
            					<label for="Mr.">Mr.</label>
            			
    					        					        						            					
            					<input id="&#039;mrs&#039;" name="mrs" type="checkbox">
            					<label for="Mrs.">Mrs.</label>
            			
    					        					        						            					
            					<input id="&#039;otherm&#039;" name="otherm" type="checkbox">
            					<label for="Others">Others</label>
            			
    					        					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					    	
    					    </div>
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     					<label for="Gender">Gender</label>
    					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
    					        					    <div class="form-group">
    						    						    					        						    					        						    					        						    					        						    					        						    					        						    					        						            					
            					<input id="&#039;male&#039;" name="male" type="checkbox">
            					<label for="Male">Male</label>
            			
    					        					        						            					
            					<input id="&#039;female&#039;" name="female" type="checkbox">
            					<label for="Female">Female</label>
            			
    					        					        						            					
            					<input id="&#039;other&#039;" name="other" type="checkbox">
            					<label for="Others">Others</label>
            			
    					        					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					    	
    					    </div>
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     					<label for="New Connection">New Connection</label>
    					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
    					        					    <div class="form-group">
    						    						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						            					
            					<input id="&#039;tempconnection&#039;" name="tempconnection" type="checkbox">
            					<label for="Temporary Connection">Temporary Connection</label>
            			
    					        					        						            					
            					<input id="&#039;permconnection&#039;" name="permconnection" type="checkbox">
            					<label for="Permanent Connection">Permanent Connection</label>
            			
    					        					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					    	
    					    </div>
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     					<label for="Bill Type">Bill Type</label>
    					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
    					        					    <div class="form-group">
    						    						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						            					
            					<input id="&#039;prepaid&#039;" name="prepaid" type="checkbox">
            					<label for="Pre-Paid">Pre-Paid</label>
            			
    					        					        						            					
            					<input id="&#039;postpaid&#039;" name="postpaid" type="checkbox">
            					<label for="Post-paid">Post-paid</label>
            			
    					        					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					    	
    					    </div>
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     					<label for="E-Bill registration">E-Bill Registration</label>
    					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
    					        					    <div class="form-group">
    						    						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						            					
            					<input id="&#039;yes&#039;" name="yes" type="checkbox">
            					<label for="Yes">Yes</label>
            			
    					        					        						            					
            					<input id="&#039;no&#039;" name="no" type="checkbox">
            					<label for="No">No</label>
            			
    					        					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					    	
    					    </div>
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     					<label for="Type of Area">Type Of Area</label>
    					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
    					        					    <div class="form-group">
    						    						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						            					
            					<input id="&#039;rh&#039;" name="rh" type="checkbox">
            					<label for="Residential Area">Residential Area</label>
            			
    					        					        						            					
            					<input id="&#039;hb&#039;" name="hb" type="checkbox">
            					<label for="High Rise Building">High Rise Building</label>
            			
    					        					        						            					
            					<input id="&#039;ua&#039;" name="ua" type="checkbox">
            					<label for="UnAuthorized">UnAuthorized</label>
            			
    					        					        						            					
            					<input id="&#039;jj&#039;" name="jj" type="checkbox">
            					<label for="Juhgi Jhopri">Juhgi Jhopri</label>
            			
    					        					        						            					
            					<input id="&#039;dd&#039;" name="dd" type="checkbox">
            					<label for="DDA Flat">DDA Flat</label>
            			
    					        					        						    					        						            					
            					<input id="&#039;vi&#039;" name="vi" type="checkbox">
            					<label for="Village Area">Village Area</label>
            			
    					        					        						            					
            					<input id="&#039;industrialarea&#039;" name="industrialarea" type="checkbox">
            					<label for="Industial Area">Industial Area</label>
            			
    					        					        						            					
            					<input id="&#039;sa&#039;" name="sa" type="checkbox">
            					<label for="Shopping Area">Shopping Area</label>
            			
    					        					        						            					
            					<input id="&#039;fa&#039;" name="fa" type="checkbox">
            					<label for="Farm House">Farm House</label>
            			
    					        					        						            					
            					<input id="&#039;government&#039;" name="government" type="checkbox">
            					<label for="Govt.(Flats)">Govt.(Flats)</label>
            			
    					        					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					    	
    					    </div>
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     					<label for="Type of Premises">Type Of Premises</label>
    					<span><a href="#" data-toggle="tooltip" title=" "> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
    					        					    <div class="form-group">
    						    						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						    					        						            					
            					<input id="&#039;owned&#039;" name="owned" type="checkbox">
            					<label for="Owned">Owned</label>
            			
    					        					        						            					
            					<input id="&#039;rented&#039;" name="rented" type="checkbox">
            					<label for="Rented/Lease">Rented/Lease</label>
            			
    					        					        						    					        						            					
            					<input id="&#039;companyprovided&#039;" name="companyprovided" type="checkbox">
            					<label for="Company Provided">Company Provided</label>
            			
    					        					        						            					
            					<input id="&#039;govtprovided&#039;" name="govtprovided" type="checkbox">
            					<label for="Government Provided">Government Provided</label>
            			
    					        					        						            					
            					<input id="&#039;otherspremise&#039;" name="otherspremise" type="checkbox">
            					<label for="Others">Others</label>
            			
    					        					        						    					    	
    					    </div>
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			        				 <div class="form-group custom-form-inline">
    				     				<div>	
			    	
				<input class="btn-solid-lg btn" name="submit" type="submit" value="submit">
				<button name="refresh" class="refresh btn-solid-lg btn" type="button">refresh</button>
				</form>
			</div>
		</div>
	</div>

	<!-- Footer -->
	<div class="footer">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<div class="footer-col">
						<h4>About Evolo</h4>
						<p>We're passionate about offering some of the best business growth services for startups</p>
					</div>
				</div> <!-- end of col -->
				<div class="col-md-4">
					<div class="footer-col middle">
						<h4>Important Links</h4>
						<ul class="list-unstyled li-space-lg">
							<li class="media">
								<i class="fas fa-square"></i>
								<div class="media-body">Our business partners <a class="turquoise" href="#your-link">startupguide.com</a></div>
							</li>
							<li class="media">
								<i class="fas fa-square"></i>
								<div class="media-body">Read our <a class="turquoise" href="terms-conditions.html">Terms & Conditions</a>, <a class="turquoise" href="privacy-policy.html">Privacy Policy</a></div>
							</li>
						</ul>
					</div>
				</div> <!-- end of col -->
				<div class="col-md-4">
					<div class="footer-col last">
						<h4>Social Media</h4>
						<span class="fa-stack">
							<a href="#your-link">
								<i class="fas fa-circle fa-stack-2x"></i>
								<i class="fab fa-facebook-f fa-stack-1x"></i>
							</a>
						</span>
						<span class="fa-stack">
							<a href="#your-link">
								<i class="fas fa-circle fa-stack-2x"></i>
								<i class="fab fa-twitter fa-stack-1x"></i>
							</a>
						</span>
						<span class="fa-stack">
							<a href="#your-link">
								<i class="fas fa-circle fa-stack-2x"></i>
								<i class="fab fa-google-plus-g fa-stack-1x"></i>
							</a>
						</span>
						<span class="fa-stack">
							<a href="#your-link">
								<i class="fas fa-circle fa-stack-2x"></i>
								<i class="fab fa-instagram fa-stack-1x"></i>
							</a>
						</span>
						<span class="fa-stack">
							<a href="#your-link">
								<i class="fas fa-circle fa-stack-2x"></i>
								<i class="fab fa-linkedin-in fa-stack-1x"></i>
							</a>
						</span>
					</div> 
				</div> <!-- end of col -->
			</div> <!-- end of row -->
		</div> <!-- end of container -->
	</div> <!-- end of footer -->  
	<!-- end of footer -->


	<!-- Copyright -->
	<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<p class="p-small">Copyright © 2020 <a href="https://inovatik.com">Inovatik</a> - All rights reserved</p>
				</div> <!-- end of col -->
			</div> <!-- enf of row -->
		</div> <!-- end of container -->
	</div> <!-- end of copyright --> 
	<!-- end of copyright -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

		<script type="text/javascript">

			$(document).ready(function(){
			       $('[data-toggle="tooltip"]').tooltip();
				$('.refresh').click(function(e){

					$('.build-form').trigger('reset');
				});

		  
		   	});
		   </script>

	<!-- Scripts -->
	<script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
	<script src="js/popper.min.js"></script> <!-- Popper tooltip library for Bootstrap -->
	<script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
	<script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
	<script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
	<script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
	<script src="js/validator.min.js"></script> <!-- Validator.js - Bootstrap plugin that validates forms -->
	<script src="js/scripts.js"></script> <!-- Custom scripts -->

</body>
</html>