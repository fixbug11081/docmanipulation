<form method="POST" action="http://localhost:8000/generate/bank-form" accept-charset="UTF-8"><input name="_token" type="hidden" value="todn4T4itGItvVsGYfTBTdLuLQRNpcyfrvtGbTox">

<label for="First Party Name">First Party Name</label>
<input name="firstpartyname" type="text">
<br><label for="Second Party Name">Second Party Name</label>
<input name="secondpartyname" type="text">
<br><label for="Bank name">Bank Name</label>
<input name="bankname" type="text">
<br><label for="Guaranteed Property">Guaranteed Property</label>
<input name="gaurentedproperty" type="text">
<br><label for="Gaurntee">Gaurntee</label>
<input name="gaurentee" type="text">
<br><label for="Amount">Amount</label>
<input name="amount" type="text">
<br><label for="Date">Date</label>
<input name="date" type="text">
<br><label for="Place">Place</label>
<input name="place" type="text">
<br><label for="Gaurented Amount">Gaurented Amount</label>
<input name="gaurentedamount" type="text">
<br><label for="Expiry Date">Expiry Date</label>
<input name="expirydate" type="text">
<br><label for="Serve Amount">Serve Amount</label>
<input name="serveamount" type="text">
<br><label for="Serve Date">Serve Date</label>
<input name="servedate" type="text">
<br><label for="Gaurentee Id">Gaurentee Id</label>
<input name="gaurentyid" type="text">
<br>
<input class="submit" name="submit" type="submit" value="submit">

</form>