    @extends('layouts.app')

    @section('content')
    <div class="container">
        <div class="row justify-content-center">
          @include('admin.partialtwoleafmenu')
        <div class="col-md-8">
            <div class="card">

                <div class="card-header">
                  <h3> Select Form </h3> 
                </div>

                <div class="card-body">
                    @if (session('status'))
                    <div class="alert alert-success" role="alert">
                        {{ session('status') }}
                    </div>
                    @endif

                    
                    <div id="" class="grayFormSec">
                        <div class="container"> 
                            <div class="box">
                             
                                <div class="form-group custom-form-inline appForm">


                                    {{Form::open(['url'=>'/admin/see/template/listvalue', 'method'=>'get'])}}
                                    {{Form::label('List applications records','List applications records')}}
                                    {{Form::select('templatename', $htmllist,null, ['class'=>'template form-control-select'])}}
                                    {{Form::submit('list value',['name'=>'list', 'class'=>'btn btn-primary'])}}
                                    {{Form::close()}}

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
@endsection
