@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        @include('admin.partialtwoleafmenu')
<div class="col-md-8">
    <div class="card">

        <div class="card-header">List Values of fields</div>

        <div class="card-body">
            @if (session('status'))
            <div class="alert alert-success" role="alert">
                {{ session('status') }}
            </div>
            @endif

            <div class="table-responsive">    
                <table class="table table-bordered">
                    <thead>
                        <tr>
                        @if(!empty($cols))
                            @foreach($cols as $col)
                            <th>{{$col->COLUMN_NAME}}</th>
                            @endforeach
                        @endif    
                        </tr>
                    </thead>
                    <tbody>

                        <tr border="2">
                            @if(!empty($records))
                             <?php $datas =  json_decode(json_encode($records),true);?>
                             <?php foreach ($datas[0] as $key => $value) {?>
                                <td border="2"><?php echo $value;?></td>

                            <?php }?>
                            <td href="/download">Downloads</td>
                            @else
                            <?php echo "No record found";?>
                            @endif
                            
                            
                           
                            
                            
                        </tr>

                    </tbody>
                </table> 
            </div>  
        </div>

    </div>
</div>
</div>
</div>
@endsection


