<style>
    table .btn-info, table .btn-info:hover, .modal .form-group .btn-solid-lg {
    display: inline-block;
    padding: 0.75rem 1rem;
    border: 0.125rem solid #00bfd8;
    border-radius: 2rem;
    background-color: #00bfd8;
    color: #fff;
    font: 700 0.75rem/0 "Raleway", sans-serif;
    text-decoration: none;
    transition: all 0.2s;
    }
    .modal form .btn.btn-solid-lg {padding: 1.375rem 2.625rem 1.375rem 2.625rem; text-transform: capitalize; font-size: 1rem;display:none;}
    table .link-info, table .link-info:hover {
        color: #00bfd8;
    }
    .modal .navbar {display:none;}
    .modal .footer, .modal .copyright {display:none;}
</style>

@extends('layouts.app') @section('content')
<div class="container">
	<div class="row justify-content-center">@include('admin.partialtwoleafmenu')
		<div class="col-md-9">
			<div class="alert alert-success" role="alert" id="info-message">{{$message}}</div>
			<div class="card">
				<div class="card-header">List Forms</div>
				<div class="card-body">@if (session('status'))
					<div class="alert alert-success" role="alert">{{ session('status') }}</div>@endif {{$listforms->render()}}
					<div class="table-responsive">
					    @php
					                        function ReadTemplate($filename) { 
                                                    $striped_content = '';
                                                    $content = '';
                                             
                                                    $zip = zip_open($filename);
                                             
                                                    if (!$zip || is_numeric($zip)) return false;
                                             
                                                    while ($zip_entry = zip_read($zip)) {
                                             
                                                        if (zip_entry_open($zip, $zip_entry) == FALSE) continue;
                                             
                                                        if (zip_entry_name($zip_entry) != "word/document.xml") continue;
                                             
                                                        $content .= zip_entry_read($zip_entry, zip_entry_filesize($zip_entry));
                                             
                                                        zip_entry_close($zip_entry);
                                                    }// end while
                                             
                                                    zip_close($zip);
                                             
                                                    $content = str_replace('</w:r></w:p></w:tc><w:tc>', " ", $content);
                                                    $content = str_replace('</w:r></w:p>', "\r\n", $content);
                                                    $striped_content = strip_tags($content);
                                             
                                                    return $striped_content;
                                                    
                                                    
                                                }
                        @endphp
						<table class="table table-bordered">
							<thead>
								<tr>
									<th>Id</th>
									<th>Form Name</th>
									<th>Template name</th>
									<th>Template filename</th>
									<th>Preview Form</th>
									<th>Preview Template</th>
									<th>Operation</th>
								</tr>
							</thead>
							@if(!empty($listforms)) 
							@foreach($listforms as $listform)
							<tr>
								<td>{{$listform->id}}</td>
								<td>{{ucfirst($listform->name)}}</td>
								<td>{{ucfirst($listform->templatename)}}</td>
								<td>{{ucfirst($listform->filename)}}</td>
								<td>
								    @php $rand = rand() @endphp
									<button type="button" class="btn btn-info" data-toggle="modal" data-target=#myForm{{$rand}}>Form</button>
									<!-- Modal -->
									<div id=myForm{{$rand}} class="modal fade" role="dialog">
										<div class="modal-dialog modal-lg">
											<!-- Modal content-->
											<div class="modal-content">
												<div class="modal-body">
												    @php $preview = $listform->view @endphp
												    @if($preview != 'null')
												    {!! view('form.'.$preview) !!}
												    @endif
												    @if($preview == 'null')
												     <?php echo "View is not created yet"; ?>
												    @endif
												</div>
											</div>
										</div>
									</div>
									@php 
                                        $filename = storage_path('app/template/').$listform->filename;
									    $txt = ReadTemplate($filename);
									    $txt = htmlspecialchars_decode(stripslashes($txt));
									@endphp
									
								</td>
								<td>
								    
									<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target=#myTemplate{{$rand}}>Template</button>
									<!-- Modal -->
									<div id=myTemplate{{$rand}} class="modal fade" role="dialog">
										<div class="modal-dialog modal-lg">
											<!-- Modal content-->
											<div class="modal-content">
												<div class="modal-body">
												     @php
												           $html = html_entity_decode($txt);
												           echo $html;
												     @endphp
												      
												    
												    
												</div>
											</div>
										</div>
									</div>
								</td>
								<td><a class="link-info" href={{URL::to( '/admin/delete/forms/'.$listform->id)}}>Delete</a>
								</td>
							</tr>
							@endforeach 
							@endif
							
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div id="myTemplate" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Preview Template</h4>
			</div>
			<div class="modal-body">
				<p>Some text in the modal.</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
@endsection
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
	$(document).ready(function(){
	    $( "#info-message" ).delay( 800 ).fadeOut( 400 );
	});
</script>