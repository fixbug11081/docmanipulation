                @extends('layouts.app')

                @section('content')
                <div class="container">
                    <div class="row justify-content-center">
                      @include('admin.partialmenu')
                <div class="col-md-10">
                    <div class="card">

                        <div class="card-header">
                            Create Form
                        </div>

                        <div class="card-body">
                            @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                            @endif


                            <!-- tools -->
                            <div id="" class="grayFormSec">
                                <div class="container">

                                    <div class="box12">
                            <h2><label>Create {{$templatename}} template<label></h2>
                                            <div class="form-group" >
                                                <form action="/admin/save/template/{{$templatename}}" method="post" >
                                                <input type=hidden name=_token value={{csrf_token()}}> 
                                                </input>
                                                @if(!$fail)
                                                   <div class="alert alert-danger">
                                                    {{$fail}}
                                                    </div>
                                                @endif     
                                                <div class="row bg-white">
                                                  <div class="col-lg-6"> 
                                                      <textarea id='contentid' 
                                                      name="templatecontent"
                                                      rows=20 
                                                      cols=50                                             
                                                      style = 'resize:vertical'>
                                                      {{$editcontent}}
                                                  </textarea>

                                              </div>

                                              <div class="col-lg-6 gaurantee-formate"> 
                                               <div id="doc"></div>

                                           </div>  
                                       </div>
                                       <input type="submit"                                    
                                       value="Save file" 
                                       class="btn-solid-lg btn" ></button>

                                   </form>



                               </div>

                               <button type="button"
                               onclick="htmlrender()"
                               value="Document" 
                               class="btn-solid-lg btn" >Document</button>



                           </div> <!-- end of col -->

                       </div> <!-- end of container custom-form-inline" -->
                   </div> <!-- end of form-1 -->
                   <!-- end of request -->
               </div>
           </div>
       </div>
   </div>

   <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
   <script src="js/popper.min.js"></script> <!-- Popper tooltip library for Bootstrap -->
   <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
   <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
   <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
   <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
   <script src="js/validator.min.js"></script> <!-- Validator.js - Bootstrap plugin that validates forms -->
   <script src="js/scripts.js"></script> <!-- Custom scripts -->
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

   <script type="text/javascript">
    function htmlrender(){

        var template = document.getElementById('contentid').value;

        var  txt = document.getElementById('doc');
        txt.innerHTML=template;
    }


</script>

@endsection
