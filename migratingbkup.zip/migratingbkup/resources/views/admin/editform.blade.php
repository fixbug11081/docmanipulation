   <!-- @extends('layouts.app')-->

    @section('content')
    <div class="container">
        <div class="row justify-content-center">
           @include('admin.partialtwoleafmenu')
        <div class="col-md-6">
            <div class="card">

                <div class="card-header">
                   <h3> Edit Form </h3>
                </div>

                <div class="card-body">
                    @if (session('status'))
                    <div class="alert alert-success" role="alert">
                        {{ session('status') }}
                    </div>
                    @endif

                    
                    <div id="" class="grayFormSec">
                        <div class="container"> 
                            <div class="box">
                             
                                <div class="form-group custom-form-inline appForm">
                                    @if (count($errors) > 0)
                                    <div class="alert alert-danger">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                        <li><font color=red>{{ $error }}</fonr></li>
                                            @endforeach
                                        </ul>
                                    </div>

                                    @endif   

                                    {{Form::open(['url'=>'/admin/edit-application-form', 'method'=>'post'])}}
                                    <?php echo "<br/>";?>
                                    {{Form::label('Select Form to Edit',null,['class'=>'label-control'])}}
                                   {{Form::select('listofform', $form, null,['class'=>'form-control-input', 'id'=>'listofform'])}}
                                    <!--{{Form::token()}}-->
                                    <?php echo "<br/>";?>
                                    {{Form::submit('submit', ['name'=>'submit', 'class'=>"btn btn-primary" ])}}
                                    {{Form::close()}}
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                </div>

            </div>
        </div>
        
</div>
@endsection
