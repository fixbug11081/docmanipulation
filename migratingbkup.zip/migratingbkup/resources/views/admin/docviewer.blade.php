<div class="editorSec">
<textarea name="editor1">{{$content}}</textarea>
<script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
<script>
CKEDITOR.replace( 'editor1' );
</script>
</div>