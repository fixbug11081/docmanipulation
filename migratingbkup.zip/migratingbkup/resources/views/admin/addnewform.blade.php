   <!-- @extends('layouts.app')-->

    @section('content')
    <div class="container">
        <div class="row justify-content-center">
           @include('admin.partialtwoleafmenu')
        <div class="col-md-8">
            <div class="card">

                <div class="card-header">
                   <h3> Create Form </h3>
                </div>

                <div class="card-body">
                    @if (session('status'))
                    <div class="alert alert-success" role="alert">
                        {{ session('status') }}
                    </div>
                    @endif

                    
                    <div id="" class="grayFormSec">
                        <div class="container"> 
                            <div class="box">
                             
                                <div class="form-group custom-form-inline appForm">
                                    @if (count($errors) > 0)
                                    <div class="alert alert-danger">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                        <li><font color=red>{{ $error }}</fonr></li>
                                            @endforeach
                                        </ul>
                                    </div>

                                    @endif   

                                    {{Form::open(['url'=>'/admin/save-application-form', 'method'=>'post'])}}
                                    <?php echo "<br/>";?>
                                    {{Form::label('Form name',null,['class'=>'label-control'])}}
                                    <span><a href="#" data-toggle="tooltip" title="No spaces,special character and digits are allowed,Use small cases only"> <i class="fa fa-question-circle" aria-hidden="true"></i></a></span>
             
				
                                    {{Form::text('name',null,['class'=>'form-control-input'])}}
                                    <!--{{Form::token()}}-->
                                    <?php echo "<br/>";?>
                                    {{Form::submit('submit', ['name'=>'submit', 'class'=>"btn btn-primary" ])}}
                                    {{Form::close()}}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
@endsection
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script type="text/javascript">
        $(document).ready(function(){
                $('[data-toggle="tooltip"]').tooltip();
        });
</script>
    
