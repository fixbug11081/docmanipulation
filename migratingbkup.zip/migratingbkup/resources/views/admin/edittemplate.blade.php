<!--    @extends('layouts.app')-->
     <link rel="icon" href="images/favicon.png">

    @section('content')
    <div class="container">
        <div class="row justify-content-center">
           @include('admin.partialtwoleafmenu')
           <div class="col-md-8">
            <div class="card">

                <div class="card-header">
                  <span>
                  <h3> Edit  Template  </h3>  
                  
                    <a href="#" data-toggle="tooltip" title="Select the template for editing in ms document"> 
                        <i class="fa fa-question-circle" aria-hidden="true"></i>
                    </a>
                  </span>    
                </div>

                <div class="card-body">
                    @if (session('status'))
                    <div class="alert alert-success" role="alert">
                        {{ session('status') }}
                    </div>
                    @endif

                    
                    <div id="" class="grayFormSec">
                        <div class="container"> 
                            <div class="box">
                             
                                <div class="form-group custom-form-inline appForm">
                                    @if (count($errors) > 0)
                                    <div class="alert alert-danger">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                        <li><font color=red>{{ $error }}</fonr></li>
                                            @endforeach
                                        </ul>
                                    </div>

                                    @endif 
                            
                                    @if( $message !=null)  
                                    <div class="alert alert-success">
                                 	  {{$message}}
                                    </div>
                                    @endif

									<div class="form-group custom-form-inline">
									{{Form::open(['url'=>'/admin/template/editor', 'method'=>'get'])}}
									{{Form::label('Edit Template ', 'Edit Input Template', [ 'class' => '', ])}}
								    <input type='hidden' name='segment' value={{$segment}} />
									{{Form::select('formname', $formname,null, ['class'=>'formname form-control-select'])}}
									<a href="#" data-toggle="tooltip" title="Edit  template in template editor pane"> 
                                     
									{{Form::submit('Edit Template',['name'=>'create-template','class'=>'btn btn-primary'])}}
                                    </a>
									{{Form::close()}}
                                   <!-- {{Form::open(['url'=>'/admin/template/edit', 'method'=>'get'])}}
                                    {{Form::label('Edit Template ', 'Edit Input Template', [ 'class' => '', ])}}
                                    {{Form::select('formname', $formname,null, ['class'=>'formname form-control-select'])}}
                                    <a href="#" data-toggle="tooltip" title="Upload the predefined template in ms document"> 
                                        {{Form::submit('Edit Template',['name'=>'edit-template','class'=>'btn btn-primary'])}}
                                    </a>
                                    {{Form::close()}}-->


									</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
@endsection

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

        <script type="text/javascript">
        $(document).ready(function(){
                $('[data-toggle="tooltip"]').tooltip();
        });
        </script>