    <style>
    /** select box css **/
    #output {
      padding: 20px;
      background: #dadada;
    }
    
   
    
    select {
      width: 300px;
    }
    /*****************/
	form .form-group {
		margin-bottom: 0;
	}
	
	form .append {
		margin-left: .25em;
	}
	
	form .table thead th {
		vertical-align: top;
		padding-top: 30px;
	}
	
	.table th {
		border-top: 0px!important;
	}
	
	form .form-control-input {
		padding-top: 0.0625rem;
		margin-bottom: 0px;
		padding-left: 0.5rem;
	}
	
	form .form-control-select {
		padding-top: .43rem;
		padding-bottom: 0.43rem;
		margin-bottom: 0px;
		padding-left: 0.35rem;
	}
	
	.main-field {
		margin-left: -15px;
	}
	
	.main-field label {
		font-weight: 700;
	}
	
	.add-new-button {
		position: relative;
	}
	
	.add-new-button .btn {
		position: absolute;
		right: 15px;
		bottom: 15px;
	}
	
	a.sel {
		color: #212529;
		line-height: 1.5rem;
	}
	
	a.sel input {
		vertical-align: -1px;
	}
	
	a.sel:hover {
		text-decoration: none;
	}
	
	#nooffields.form-control-input {
		padding-top: 0.0625rem;
		margin-bottom: 0px;
		padding-left: 0.5rem;
	}
	
	.btn.btn-primary:focus {
		box-shadow: none!important;
	}
	
	.dropdown-menu.show {
		padding-left: 0.5rem;
	}
	
	#displayed {
		display: none;
	}
/**	.modal #displaying table tr:last-child {display:none;}**/
	#displaying table {width:100%;border: 1px solid #dee2e6;}
	#displaying table td:first-child {width:40%;}
	#displaying table td:last-child {width:60%;}
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
</style>

@extends('layouts.app') @section('content')
<div class="container">
	<div class="row justify-content-center">@include('admin.partialtwoleafmenu')
		<div class="col-md-9">
			<div class="card">
				<div class="card-header">	<a href="#" data-toggle="tooltip" title="DocMaster application form!"> Document Forms</a>
				</div>
				<div class="card-body">@if (session('status'))
					<div class="alert alert-success" role="alert">{{ session('status') }}</div>@endif
					<div id="" class="grayFormSec">
						<div class="container">
							<div class="row">
								<div class="col-md-6 main-field add-new-button">
									<div class="form-group">{{Form::label('Number of rows')}} {{Form::number('nooffields', null, ['class'=>'form-control-input', 'id' => 'nooffields'])}}
										<button id="addrow" class="btn btn-primary">	<i class="fa fa-plus"></i>Add</button>
									</div>
								</div>
							</div>
							
						</div>
					    @if($urlsegment ?? '' == 'edit-application-form')
						{{Form::open([ "url"=>"/admin/save/edit-fields", "method"=>"POST", "class"=>"build-form"])}}
						@endif
						@if($urlsegment ?? '' == 'save-application-form')
						{{Form::open([ "url"=>"/admin/save/fields", 
						"method"=>"POST", "class"=>"build-form"])}}
						@endif
						
				        
						<div class="col-md-6 main-field">
							<div class="form-group">{{Form::label('Form name')}} {{Form::select('formname', $formname,null, ['class'=>'form-control-select', 'id'=>'formid'])}}</div>
						</div>
						<div class="table-responsive">
							<table class="table table-striped" id="tbladdrow">
								<thead>
									<tr>
										<th scope="col">#</th>
										<th scope="col" style="min-width: 160px;">Generic Fields</th>
									
										<th scope="col" style="min-width: 180px;">Conditional Column</th>
										<th scope="col" style="min-width: 140px;">Value In Box	<span class="glyphicon glyphicon-question-sign append text-info tip" data-tip="tip-third">
												<i class="fa fa-question-circle" aria-hidden="true"></i>
											</span>
											<div id="tip-third" class="tip-content d-none">
												<h2>Value in box</h2>
												<p>Text value get into box character by character,if it is checked.</p>
											</div>
										</th>
										<th scope="col" style="min-width: 160px;">Option field flag</th>
										<th scope="col" style="min-width: 160px;">Label</th>
										<th scope="col" style="min-width: 160px;">Placeholder</th>
										<th scope="col" style="min-width: 160px;">Tooltips</th>
										<th scope="col" style="min-width: 160px;">Sequence</th>
										<th scope="col" style="min-width: 160px;">Option Options</th>
										<th scope="col" style="min-width: 80px;">Action</th>
									</tr>
								</thead>
								<tbody>
										
									<!-- Edit form  -->
									
									@if($urlsegment  == 'edit-application-form')
									<?php $j = 1; ?>
									    @foreach($values as $value)
									        	<td scope="row" style="vertical-align: middle;" id=sno>{{$j}}</td>
										<td>
											<div class="form-group" style="position:relative;width:200px;">
												<select class="form-control-select generic" id="field{{$j}}" name="fieldname[]" style="position:absolute;width:200px;" onchange="document.getElementById('displayValue{{$j}}').value=this.options[this.selectedIndex].text; document.getElementById('idValue{{$j}}').value=this.options[this.selectedIndex].value;   document.getElementById('displayValue{{$j}}').disabled= true" data-toggle="modal" data-target="">
													<option></option>
										<option value={{$value->id}}>
													{{$value->id}}</option>
									@foreach($genericfields as $genericfield)
        						@if($genericfield->id == $value->genericid)	
        						<?php $str = $genericfield->genericfield;?>
            					<option value={{$genericfield->id}} selected>
            								{{$genericfield->genericfield}}</option>
            									@else
            								<option value={{$genericfield->id}}> {{$genericfield->genericfield}}</option>
        								@endif
									@endforeach
									</select>
									<input type="text" name="displayValue[]" 
												id=displayValue{{$j}}
										value={{$str}}		
										placeholder="add/select a value" class=displaytext onfocus="this.select()" style="position:absolute;top:1px;left:2px;width:175px;border:0px;    padding: 5px;">			
												<input name="idValue[]" class="optiontxt" id=idValue{{$j}} type="hidden">
											</div>
										</td>
								
										<td style="text-align:center;vertical-align: middle;">

<input type=text 
id=sub-fields{{$j}} name=subfields[] value='{{$value->subfield}}' 
class='sub form-control-input' >
											<div id="optionModal" class="modal fade" role="dialog" tabindex="-1" data-backdrop="static">
												<div class="modal-dialog" role="document">
													<!-- Modal content-->
													<div class="modal-content">
														<div class="modal-header">
															<h5 class="modal-title">Option Fields</h5>
															<button type="button" class="close" data-dismiss="modal" aria-label="Close">	<span aria-hidden="true">&times;</span>
															</button>
														</div>
														<div class="modal-body">
															<form>
																<div class="input-group mb-3">
																	<input type="number" min="2" max="10" class="form-control form-control-input optionno" name=noofoptions id="optionboxes" placeholder="Number of Options">
																	<div class="input-group-append">
																		<input class="btn btn-primary create" type=button value=Create>
																	</div>
																</div>
																<!--<label for="inputOption" class="col-sm-5 col-form-label">Number of Options</label>-->
																<div id="displaying"></div>
															</form>
														</div>
														<div class="modal-footer">
															<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
															<input class="btn btn-primary" type=button value=click id=tablemodal>
														</div>
													</div>
												</div>
											</div>
										</td>
										<td style="text-align:center;vertical-align: middle;">
											<div class="form-group">
											     <input type="hidden" name="boxflag[]" value="0">
											    {{Form::checkbox('boxflag[]',null,0,[])}}
												<!--{{Form::label('Value in box')}}-->
											</div>
										</td>
										<td>
											<div class="form-group">{{Form::text('label',$value->label ,['name'=>'label[]', 'class'=>'form-control-input'])}} @if($errors->has('name'))	<span class="text-danger">{{ $errors->first('label') }}</span> @endif</div>
										</td>
										<td>
											<div class="form-group">{{Form::text('placeholder',$value->placeholder,['name'=>'placeholder[]', 'class'=>'form-control-input'])}} @if($errors->has('placeholder'))	<span class="text-danger">{{ $errors->first('label') }}</span> @endif</div>
										</td>
										<td>
											<div class="form-group">{{Form::text('tooltips',$value->tooltips,['name'=>'tooltips[]', 'class'=>'form-control-input'])}} @if($errors->has('name'))	<span class="text-danger">{{ $errors->first('label') }}</span> @endif</div>
										</td>
										
										<td>
											<div class="form-group">
                    							<select class=form-control-select name="sequence[]" >
                    							 @for ($i = 1; $i< 100; $i++) 
                    							    @if($i == $value->sequence)
                    							     <option value={{$i}} selected>
                    							        {{$i}}
                    							    </option>
                    							    @else
                    							      <option value={{$i}}>{{$i}}</option>
                    							    @endif
                    							   @endfor</select>
											</div>
										</td>
										<td>
										<div class="form-group" style="position:relative;width:200px;">
											<select class="form-control-select " id="field{{$j}}" name="fieldname[]" style="position:absolute;width:200px;" onchange="document.getElementById('displayValue{{$j}}').value=this.options[this.selectedIndex].text; document.getElementById('idValue{{$j}}').value=this.options[this.selectedIndex].value;   document.getElementById('displayValue{{$j}}').disabled= true" data-toggle="modal" data-target="">
													<option></option>
									    	<option value={{$value->id}}>{{$value->id}}</option>
        									@foreach($genericfields as $genericfield)
                        						@if($genericfield->id == $value->genericid)	
                        						<?php $str = $genericfield->genericfield;?>
                            					<option value={{$genericfield->id}} selected>
                            								{{$genericfield->genericfield}}</option>
                            									@else
                            					<option value={{$genericfield->id}}> {{$genericfield->genericfield}}</option>
                        								@endif
        									@endforeach
        									</select>
										 </div>
										</td>
										<td style="vertical-align:middle;">
											<!--<a href="#" id='edit'>	<i aria-hidden="true" class="fa fa-edit" style="color: rgba(0, 0, 255, .7);margin: 0 5px;font-size: 1.1rem;"></i>
											</a>-->
											<a href="#" id='del'>	<i aria-hidden="true" class="fa fa-trash" style="color: rgba(255, 0, 0, .7);margin: 0 5px;font-size: 1.1rem;"></i>
											</a>
										</td>
										</tr>
									    <?php $j = $j +1; ?>
									    @endforeach
									@endif
									<!-- Save Application form -->
									@if($urlsegment ?? '' == 'save-application-form')
									    @for($j=1;$j<=5;$j++) 
									    <tr>
										<td scope="row" style="vertical-align: middle;" id=sno>{{$j}}</td>
										<td>
											<div class="form-group" style="position:relative;width:200px;">
												<select class="form-control-select generic" id="field{{$j}}" name="fieldname[]" style="position:absolute;width:200px;" onchange="document.getElementById('displayValue{{$j}}').value=this.options[this.selectedIndex].text; document.getElementById('idValue{{$j}}').value=this.options[this.selectedIndex].value;   document.getElementById('displayValue{{$j}}').disabled= true" data-toggle="modal" data-target="">
													<option></option>@foreach($genericfields as $genericfield)
													<option value={{$genericfield->id}}> {{$genericfield->genericfield}}</option>@endforeach</select>
												<input type="text" name="displayValue[]" id=displayValue{{$j}} placeholder="add/select a value" class=displaytext onfocus="this.select()" style="position:absolute;top:1px;left:2px;width:175px;border:0px;    padding: 5px;">
												<input name="idValue[]" class="optiontxt" id=idValue{{$j}} type="hidden">
											</div>
										</td>
									
										<td style="text-align:center;vertical-align: middle;">

			<input type=text id=sub-fields{{$j}} name=subfields[] class='sub form-control-input' />
											<div id="optionModal" class="modal fade" role="dialog" tabindex="-1" data-backdrop="static">
												<div class="modal-dialog" role="document">
													<!-- Modal content-->
													<div class="modal-content">
														<div class="modal-header">
															<h5 class="modal-title">Option Fields</h5>
															<button type="button" class="close" data-dismiss="modal" aria-label="Close">	<span aria-hidden="true">&times;</span>
															</button>
														</div>
														<div class="modal-body">
															<form>
																<div class="input-group mb-3">
																	<input type="number" min="2" max="10" class="form-control form-control-input optionno" name=noofoptions id="optionboxes" placeholder="Number of Options">
																	<div class="input-group-append">
																		<input class="btn btn-primary create" type=button value=Create>
																	</div>
																</div>
																<!--<label for="inputOption" class="col-sm-5 col-form-label">Number of Options</label>-->
																<div id="displaying"></div>
															</form>
														</div>
														<div class="modal-footer">
															<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
															<input class="btn btn-primary" type=button value=click id=tablemodal>
														</div>
														
													</div>
												</div>
											</div>
										</td>
										<td style="text-align:center;vertical-align: middle;">
										    <input type="hidden" name="boxflag[]" value="0">
											<div class="form-group">{{Form::checkbox('boxflag[]',null,0,[])}}
												<!--{{Form::label('Value in box')}}-->
											</div>
										</td>
										<td style="text-align:center;vertical-align: middle;">
											<div class="form-group">
											    <input type="hidden" name="optionflags[]" value="0">
											    {{Form::checkbox('optionflags[]',null,false,['id'=>'optionflags'.rand()])}}
												<!--{{Form::label('Value in box')}}-->
											</div>
										</td>
										<td>
											<div class="form-group">{{Form::text('label',null ,['name'=>'label[]', 'class'=>'form-control-input'])}} @if($errors->has('name'))	<span class="text-danger">{{ $errors->first('label') }}</span> @endif</div>
										</td>
										<td>
											<div class="form-group">{{Form::text('placeholder',null,['name'=>'placeholder[]', 'class'=>'form-control-input'])}} @if($errors->has('placeholder'))	<span class="text-danger">{{ $errors->first('label') }}</span> @endif</div>
										</td>
										<td>
											<div class="form-group">{{Form::text('tooltips',null,['name'=>'tooltips[]', 'class'=>'form-control-input'])}} @if($errors->has('name'))	<span class="text-danger">{{ $errors->first('label') }}</span> @endif</div>
										</td>
										<td>
											<div class="form-group">
												<select class=form-control-select name="sequence[]" >
											@for ($i = 1; $i< 100; $i++) <option value={{$i}}>{{ $i }}</option>@endfor</select>
											</div>
										</td>
										<td>
											<div class="form-group" style="position:relative;width:200px;">
												<select class="form-control-select " id="field{{$j}}" name="optionoptionsid[]" style="position:absolute;width:200px;"  data-toggle="modal" data-target="">
													<option></option>@foreach($genericfields as $genericfield)
													<option value={{$genericfield->id}}> {{$genericfield->genericfield}}</option>
													@endforeach</select>
												<!--<input type="text" name="displayValue[]" id=displayValue{{$j}} placeholder="add/select a value" class=displaytext onfocus="this.select()" style="position:absolute;top:1px;left:2px;width:175px;border:0px;    padding: 5px;">
												<input name="idValue[]" class="optiontxt" id=idValue{{$j}} type="hidden">-->
											</div>
										</td>
										<td style="vertical-align:middle;">
											<!--<a href="#" id='edit'>	<i aria-hidden="true" class="fa fa-edit" style="color: rgba(0, 0, 255, .7);margin: 0 5px;font-size: 1.1rem;"></i>
											</a>-->
											<a href="#" id='del'>
						
											   	<i aria-hidden="true" class="fa fa-trash" style="color: rgba(255, 0, 0, .7);margin: 0 5px;font-size: 1.1rem;"></i>
											</a>
										</td>
										</tr>@endfor
									@endif
									
										<div id='addnewrow'></div>
								</tbody>
							</table>
						</div>
						<div class="form-group" style="text-align:right;margin-top:20px;">{{Form::button('Refresh', ['name'=>'refresh', 'class'=>'refresh btn btn-primary' ])}} {{Form::submit('Submit', ['name'=>'submit', 'class'=>'submit btn btn-primary' ])}} {{Form::close()}}</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>@endsection
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script type="text/javascript">
	var tdindex='';
	$(document).ready(function() {
		$('#addrow').on('click', function() {
			var nooffields = $('#nooffields').val();
			if(nooffields == '') {
				alert('Please fill the number of rows');
			}
			var j = 6,
				k, l = 1;
			k = $('#tbladdrow tr:last').find('td:first').text();
			var max = (+j) + (+nooffields);
			var lastRow = $('#tbladdrow tbody tr:last').html();
			for(j = 6; j < max; j++) {
				$('#tbladdrow tbody').append('<tr>' + lastRow + '</tr>');
				//$('#tbladdrow tbody tr:last input').val('');
				$('#tbladdrow tr:last').find('td:first').html((+k) + (+1));
				k = (+k) + (+1);
				$('#tbladdrow tbody tr:last').find('td:eq(1) select').attr('onchange', 'document.getElementById(' + "'" + 'displayValue' + k + "'" + ').value=this.options[this.selectedIndex].text;document.getElementById(' + "'" + 'idValue' + k + "'" + ').value=this.options[this.selectedIndex].value;');
				$('#tbladdrow tbody tr:last').find('td:eq(1) input ').attr('id', 'displayValue' + k);
				$('#tbladdrow tbody tr:last').find('td:eq(1) input:hidden ').attr('id', 'idValue' + k);
	            $('#tbladdrow tbody tr:last').find('td:eq(2) input').attr('id', 'sub-fields' + k);
	            $('#tbladdrow tbody tr:last').find('td:eq(2) input').attr('value', '');
	            $('#tbladdrow tbody tr:last').find('td:eq(4) input').attr('value', '');
	            $('#tbladdrow tbody tr:last').find('td:eq(5) input').attr('value', '');
	            $('#tbladdrow tbody tr:last').find('td:eq(6) input').attr('value', '');
	            $('#tbladdrow tbody tr:last').find('td:eq(1) input').attr('value', 'add/select a value');
	            $('#tbladdrow tbody tr:last').find('td:eq(7) input').attr('value', k+1);
	            
			
			}
		});
		
		//Add the option on select field 
		$(".generic").on('change',function(e){
	     
		    var opttext = this.options[e.target.selectedIndex].text;
		    var dp = opttext.substring(0,2);
		 
		    tdindex =$(this).closest('td').prev('td').text();
		
		    if(dp == "DP" || dp == "CH" || dp == "RB" || dp =="MS" )
		    {
		          $('#optionModal').modal("show");
		    }else{
		        
		          $('#sub-fields'+tdindex).val("");
		         
		    }
		    
		});
		
		$("#tbladdrow tbody").on("change", ".generic", function(e){
            var opttext = this.options[e.target.selectedIndex].text;
		    var dp = opttext.substring(0,2);
		    tdindex =$(this).closest('td').prev('td').text();
		  if(dp == "DP" || dp == "CH" || dp == "RB" || dp=="MS")
		    {
		          $('#optionModal').modal("show");
		    }else{
		       
		          $('#sub-fields'+tdindex).val("");
		         
		    }
        });
	     	//pop up the modal save the options
		$('#tablemodal').on('click',function(e){
		     
	    	    var values = $("input[id='optionvalues']")
	    	                  .map(function(){return $(this).val();}).get();
	    	    var arr = values.toString().split(",");
	    	    var limitation = ""; 
	    	    $.each(arr, function(index, optionlabel){
	    	         limitation = limitation+arr[index]+" || ";
	    	     });
	            limitation = limitation.substring(0,limitation.length-3);
	            
	     	    $('#sub-fields'+tdindex).val(limitation);
	            $('.optval').val('');
	            $('.optionno').val('');
	            $('#optionModal').modal('toggle');
	    });
		//Add the optional fields 
		$('#tbladdrow').on('click', 'tr td input:checkbox', function(e) {});
		$(".create").on("click", function() {
		    var i=1;
		    var tbl = "<table><tbody>", endtbl="</tbody></table>";
			var htm =  "<tr><td><label>OPTION</label></td><td><div><input type=text class='form-control-input optval' name=noofoptions[] id=optionvalues></div></td></tr>";
			var val = $('#optionboxes').val();
			var opt = "";
			for(var i = 0; i < val; i++) {
				opt = opt + htm;
			}
			$('#displaying').html(tbl+opt+endtbl);
			
		});
		//Get all the value in options
		
		
		//Delete row on click to trash link
		$('#tbladdrow').on('click', 'tr a', function(e) {
			var lenRow = $('#tbladdrow tbody tr').length;
			e.preventDefault();
			if(lenRow == 1 || lenRow <= 1) {
				alert("Can't remove all row!");
			} else {
			    $(this).parents('tr').remove();
			}
		});
		$('[data-toggle="tooltip"]').tooltip();
		$('.tip').each(function() {
			$(this).tooltip({
				html: true,
				title: $('#' + $(this).data('tip')).html()
			});
		});
		$('.refresh').click(function(e) {
			$('.build-form').trigger('reset');
		});
		$('#plainfield').change(function() {
			if($(this).is(':checked')) {
				$('#groupfields').prop("checked", true);
				$('#optiongroupbox').addClass('hide-select');
				$('#optionfieldsbox').addClass('hide-select');
			} else {
				$('#optiongroupbox').removeClass('hide-select');
			}
		});
		$('#groupfields').change(function() {
			if($(this).is(':checked')) {
				$('#optionfieldsbox').addClass('hide-select');
			} else {
				// $('#optionfieldsbox').removeClass('hide-select'); 
			}
		});
		$('#fieldtype').change(function() {
			var optionfield = $('#fieldtype').val();
			var formid = $('#formid').val();
			if(optionfield == 3) {
				$('#optiongroupbox').addClass('hide-select');
				$('#settextfield').addClass('hide-select');
				$('#optionfieldsbox').removeClass('hide-select');
				$.ajax({
					type: 'GET',
					url: '/get/options/' + formid,
					success: function(response) {
						$('#optionfieldsbox').html(response);
					},
					error: function(xhr) {
						$('#optionfieldsbox').html("<p>Ajax call</p>");
						alert('error' + xhr.responseText);
					}
				});
			} else {
				$('#optiongroupbox').removeClass('hide-select');
				$('#settextfield').removeClass('hide-select');
				$('#optionfieldsbox').addClass('hide-select');
			}
		});
	});
</script>
<!----dropdown multiple select ----->
<script>
	var options = [];
	$('.dropdown-menu a').on('click', function(event) {
		var $target = $(event.currentTarget),
			val = $target.attr('data-value'),
			$inp = $target.find('input'),
			idx;
		if((idx = options.indexOf(val)) > -1) {
			options.splice(idx, 1);
			setTimeout(function() {
				$inp.prop('checked', false)
			}, 0);
		} else {
			options.push(val);
			setTimeout(function() {
				$inp.prop('checked', true)
			}, 0);
		}
		$(event.target).blur();
		console.log(options);
		return false;
	});
</script>
