                      @extends('layouts.app')

                      @section('content')
                      <div class="container">
                        <div class="row justify-content-center">
                          @include('admin.partialmenu')
                          <div class="col-md-7">
                            <div class="card">

                              <div class="card-header">
                               <h3> Upload Template File </h3>
                              </div>

                              <div class="card-body">

                               <!--  @if (!empty(session('status')))
                                <div class="alert alert-success" role="alert">
                                  {{ session('status') }}
                                </div>
                                @endif
                              -->

                              <!-- tools -->
                              <div id="" class="grayFormSec">
                                <div class="container">

                                  <div class="box12">
                                    <h2><label>Upload  {{$templatename}} template<label></h2>
                                      <div class="form-group" >
                                        <form action="/admin/upload/{{$templatename}}" 
                                        method="post"  
                                        enctype="multipart/form-data">
                                      <input type="hidden" name="_token" value={{csrf_token()}}> 
                                       
                                        @if(!empty($fail))
                                        <div class="alert alert-danger">
                                          {{$fail}}
                                        </div>
                                        @endif     
                                        @if(!empty($message))
                                        <div class="alert alert-success">
                                          {{$message}}
                                        </div>
                                        @endif 
                                        <div class="row bg-white">
                                          <div class="col-lg-6"> 
                                            <input type="file" 
                                            name="templatefile"
                                            enctype="multipart/form-data">
                                          </div>
                                        </div>
									<br/>
                                        <input type="submit"                        
                                        value="Upload file" 
                                        class="btn btn-primary" >

                                      </form>



                                    </div>




                                  </div> <!-- end of col -->

                                </div> <!-- end of container custom-form-inline" -->
                              </div> <!-- end of form-1 -->
                              <!-- end of request -->
                            </div>

                          </div>

                        </div>
                        <!-- template fields -->
                        <div class="col-md-2">
                          <div class="card-header">
                           <h3>Template Fields </h3>
                         </div>


                         @foreach($fieldsname as $field)
                         <span class="list-group-item">
                          {{$field}}
                        </span>
                        @endforeach


                      </div>


                      <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
                      <script src="js/popper.min.js"></script> <!-- Popper tooltip library for Bootstrap -->
                      <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
                      <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
                      <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
                      <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
                      <script src="js/validator.min.js"></script> <!-- Validator.js - Bootstrap plugin that validates forms -->
                      <script src="js/scripts.js"></script> <!-- Custom scripts -->
                      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

                      <script type="text/javascript">

                      </script>
                      @endsection
