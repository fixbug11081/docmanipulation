@extends('layouts.app') @section('content')
<div class="container">
	<div class="row justify-content-center">@include('admin.partialmenu')
		<div class="col-md-7">
			<div class="card">
				<div class="card-header">
				     @if(!empty($txt))
					<h3>Edit Template</h3>
					 @else
					 <h3>Create Template</h3>
					 @endif
				</div>
				<div class="card-body">
					<!--  @if (!empty(session('status')))
                                <div class="alert alert-success" role="alert">
                                  {{ session('status') }}
                                </div>
                                @endif
                              -->
					<!-- tools -->
					<div id="" class="grayFormSec">
						<div class="container">
							<div class="box12">
							    @if(!empty($txt))
								<label>Edit {{$templatename ?? '' }} template</label>&nbsp;&nbsp;&nbsp;
							    @else
								<label>Create {{$templatename ?? '' }} template</label>&nbsp;&nbsp;&nbsp;
							    @endif
									<div class="form-group">
											<form action="/admin/save/template/{{$templatename}}" method="post">
										
										<input type="submit" value="Save file" class="btn btn-primary">
										<button type="button" onclick="save()" value="Document" class="btn btn-primary">Template Preview</button>
										<br/><br/><br/>
										    
										    <input type=hidden name=segment value={{$segment}} />
												
												<input type=hidden name=_token value={{csrf_token()}}></input>@if(!empty($fail))
											
												<div class="alert alert-danger">{{$fail}}</div>@endif
												<div class="row bg-white">
													<div class="col-lg-12">
														<textarea id='contentid' name=templatecontent rows=20 cols=38>{{$txt}}</textarea>
													</div>
													<div class="col-lg-12 gaurantee-formate">
														<br/>
														<center>Template Preview</center>
														<br/>
														<div id="doc"></div>
													</div>
												</div>
												<br/>
											</form>
										</div>
							</div>
							<!-- onclick="htmlrender()"end of col -->
						</div>
						<!-- end of container custom-form-inline" -->
					</div>
					<!-- end of form-1 -->
					<!-- end of request -->
				</div>
			</div>
		</div>
		<!-- template fields -->

		<div class="col-md-2">
			<div class="card-header">
				<h3>Template Fields </h3>
			</div>
		
			@foreach($fielddetails as $field)
			<span class="list-group-item">
                <em>
                    <strong> {{$field->label}} </strong>
                </em>
            </span>
			<span class="list-group-item">
                        <?php echo "{";?>{{$field->genericfield}}<?php echo "}";?>
            </span>
			@endforeach
		  
			</div>
		<ckeditor name="content" id="content" [(ngModel)]="page.content" debounce="500" [config]="{
                    skins: 'minimalist',
                    allowedContent: true,
                    extraPlugins: 'divarea',
                    contentsCss: CKECSS
                  }" (ready)="setCkeObject($event)" #ckeEditor></ckeditor>
	</div>
	<!--Script for ckeditor -->
	<script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js">
	</script>
	 
        
	<script>
		CKEDITOR.replace('templatecontent',{height:'500px'});
		                function save() {
		                  var data = CKEDITOR.instances["contentid"].getData();
		                  var myAnchor = document.getElementById("contentid");
		                  var outputAnchor = document.getElementById("doc");
		                  var mySpan = document.createElement("div");
		                  mySpan.setAttribute('id', 'source-html');
		
		                  mySpan.innerHTML = data;
		                  var ele = document.getElementById('source-html');
		
		                  if (typeof(outputAnchor.childNodes[0]) != 'undefined' && outputAnchor.childNodes[0] != null) {
		
		                    outputAnchor.removeChild(outputAnchor.childNodes[0]);
		                    outputAnchor.appendChild(mySpan);
		
		                  } else {
		
		                    outputAnchor.appendChild(mySpan);
		                  }
		                }
		
		
		            //CKEDITOR.instances['textcontent'].destroy(true);
		           //  var editor = CKEDITOR.replace('templatecontent');
		            // CKEDITOR.instances['templatecontent'].setData();
		            // CKEDITOR.instances['templatecontent'].setReadOnly(false);
		
		            function htmlrender(){
		              var template = document.getElementById('contentid').value;
		              var  txt = document.getElementById('doc');
		              txt.innerHTML = template;
		            }
		            
		  $(document).ready(function(){
                $('[data-toggle="tooltip"]').tooltip();
		  });
		            
	</script>
	<script src="https//cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script> 
	<script src="js/jquery.min.js"></script>
	<!-- jQuery for Bootstrap's JavaScript plugins -->
	<script src="js/popper.min.js"></script>
	<!-- Popper tooltip library for Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Bootstrap framework -->
	<script src="js/jquery.easing.min.js"></script>
	<!-- jQuery Easing for smooth scrolling between anchors -->
	<script src="js/swiper.min.js"></script>
	<!-- Swiper for image and text sliders -->
	<script src="js/jquery.magnific-popup.js"></script>
	<!-- Magnific Popup for lightboxes -->
	<script src="js/validator.min.js"></script>
	<!-- Validator.js - Bootstrap plugin that validates forms -->
	<script src="js/scripts.js"></script>
	<!-- Custom scripts -->@endsection