 <div class="col-md-3">
    <div class="card">
      <div class="card-header">
       <h3> Manage </h3>
    </div>
    <ul class="list-group list-group-flush">
        <li class="list-group-item">
            <a href="/admin/create-form">Create Form</a>
        </li>
        <li class="list-group-item">
            <a href="/admin/edit-form">Edit Form</a>
        </li>
        <li class="list-group-item">
            <a href="/admin/create-view">Create Dynamic Form</a>
        </li>
        <!--<li class="list-group-item">
           <a href="/admin/application/fields">Select Form</a>
       </li>-->
        <li class="list-group-item">
          <a href="/admin/list/forms">List Forms</a>
        </li>
       <li class="list-group-item">
        <a href="/admin/create/template">Create Template</a>
       </li>
       <li class="list-group-item">
          <a href="/admin/edit/template">Edit Template</a>
       </li>
    <!--<li class="list-group-item">
       <a href="/admin/template/upload">Upload Template</a>
   </li>-->
   <!--<li class="list-group-item">
    <a href="/admin/list-template">List Template</a>-->
</li>
</ul>
</div>
</div>