 @extends('layouts.app')

    @section('content')
    <div class="container">
        <div class="row justify-content-center">
            @include('admin.partialtwoleafmenu')
        <div class="col-md-8">
            <div class="card">

                <div class="card-header">
                   <h3> Create Input Html </h3>
                </div>

                <div class="card-body">
                    @if (session('status'))
                    <div class="alert alert-success" role="alert">
                        {{ session('status') }}
                    </div>
                    @endif

                    
                    <div id="" class="grayFormSec">
                        <div class="container"> 
                            <div class="box">
                             
                                <div class="form-group custom-form-inline appForm">
                                    @if (count($errors) > 0)
                                    <div class="alert alert-danger">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                        <li><font color=red>{{ $error }}</fonr></li>
                                            @endforeach
                                        </ul>
                                    </div>

                                    @endif 
                            
                                    @if( $message !=null)  
                                    <div class="alert alert-success">
                                 	  {{$message}}
                                    </div>
                                    @endif

									<div class="form-group custom-form-inline">
									{{Form::open(['url'=>'/admin/generate/form', 'method'=>'get'])}}
									{{Form::label('Create html form', 'Create html Form', [ 'class' => '', ])}}
									{{Form::select('formname', $formname,null,
									['class'=>'formname form-control-select', 'id'=>'formid'])}}
									{{Form::submit('submit',['name'=>'generate-form','class'=>'btn btn-primary'])}}
									{{Form::close()}}
									</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

@endsection
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

        <script type="text/javascript">
        $(document).ready(function(){
                $('[data-toggle="tooltip"]').tooltip();
        });


