{{Form::label('Tools')}}
<?php echo "<br>"; ?>

{{Form::open(['url'=>'/generate/form', 'method'=>'get'])}}
{{Form::label('Create Input Form','',array('class'=>'zxc'))}}
{{Form::select('formname', $formname,null, ['class'=>'formname'])}}
{{Form::submit('Create Input  Form',['name'=>'generate-form','class'=>'generate'])}}
{{Form::close()}}
<?php echo "<br>"?>

{{Form::open(['url'=>'/get/form', 'method'=>'get'])}}
{{Form::label('Select form to fill')}}
{{Form::select('view', $viewlist,null, ['class'=>'view'])}}
{{Form::submit('select view',['name'=>'select-view','class'=>'select-view'])}}
{{Form::close()}}

<?php echo "<br>"?>

{{Form::open(['url'=>'/see/template', 'method'=>'get'])}}
{{Form::label('Select application form')}}
{{Form::select('templatename', $htmllist,null, ['class'=>'template'])}}
{{Form::submit('see',['name'=>'see'])}}
{{Form::close()}}


{{Form::open(['url'=>'/see/template/listvalue', 'method'=>'get'])}}
{{Form::label('List applications records')}}
{{Form::select('templatename', $htmllist,null, ['class'=>'template'])}}
{{Form::submit('list value',['name'=>'list'])}}
{{Form::close()}}


{{Form::open(['url'=>'/application/pdf', 'method'=>'get'])}}
{{Form::label('Downloads applications')}}
{{Form::select('templatename', $htmllist,null, ['class'=>'template'])}}
{{Form::submit('Download PDF',['name'=>'pdf'])}}

{{Form::close()}}


{{Form::open(['url'=>'/application/view/pdf', 'method'=>'get'])}}
{{Form::label('View applications')}}
{{Form::select('templatename', $htmllist,null, ['class'=>'template'])}}
{{Form::submit('View PDF',['name'=>'viewpdf'])}}	
{{Form::close()}}