<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <style>
     p{
	     line-height: 24px;
	 }
	 .input-line:focus{
	   outline:none;
	 }
	 .input-line{
	   border:none;
	   border-bottom:1px solid #000;
	 }
	 .input-width{
	    width:33%;
	 }
   </style>
</head>
<body>
<form class="guarantee-form" name="_form">
<h2><strong>Format of Lease Deed Residential Property</strong></h2>
<p>Residential Property Lease Deed Draft</p>
<p>This lease deed residential property is made on this <input class="input-line" type="text" value="" name=""> at <input class="input-line" type="text" value="" name=""> between Mr.<input class="input-line" type="text" value="" name=""> hereinafter called FIRST PARTY.</p>
<p>AND</p>
<p>Mr. <input class="input-line" type="text" value="" name="">, hereinafter called the SECOND PARTY.</p>
<p>That the expressions of both the parties shall mean and include the parties, their respective legal heirs, successors administrators &amp; assignees.</p>

<p>That whereas First Party is the complete owner and in absolute possession of residential unit bearing number <input class="input-line" type="text" value="" name=""> hereinafter called as property and out of which First Party for his bonafide needs and requirement has agreed to let out to the Second Party/Tenant. And the Second Party shall use the above mentioned demised premises for RESIDENTIAL PURPOSE ONLY.</p>
<p>AND WHEREAS the Second Party has requested and approached the First Party for permission to give on rent of the said premises.</p>
<p>And whereas the First Party accepted the request of the Second Party and authorized him to use the aforesaid premises on rent on a monthly rent charges of Rs<input class="input-line" type="text" value="" name="">, the charges for consumption of electricity in the demised premise shall be paid and/or borne by the party of the second part on the basis of the bills received from time to time for which purpose the party of the first part shall provide. Also all the arrears/dues in electricity bills till the date of signing of the agreement will be born by the first party and also the party of the first part will handover the electric &amp; water meter in perfect running conditions.</p>
<p><strong>NOW, THIS AGREEMENT BETWEEN THE PARTIES AS UNDER:-</strong></p>
<p>1. That the agreed period of the tenancy is <input class="input-line" type="text" value="" name=""> to <input class="input-line" type="text" value="" name=""> only and the second party/tenant has agreed to pay a sum of Rs.<input class="input-line" type="text" value="" name=""> as rent charges to the first party on or before 7th Day of English Calendar month always in advance. And the rent of the said premises shall be paid through cheque/cash by the second party per month. The second party has paid an amount of Rs.<input class="input-line" type="text" value="" name=""> as advance vide cheque No.<input class="input-line" type="text" value="" name=""> dated drawn<input class="input-line" type="text" value="" name="">In favour of the First Party as advance security which shall be kept as interest free security by the First Party and shall be returned back to the second party on completion of the above stated period of stay of the Second Party in the premises of the First Party.</p>
<p>2. That the second party/tenant will abide by all the rules and regulations of the competent authorities, government agencies enforced from time to time.</p>
<p>3. That the second party/tenant will keep the said portion of the <a href="">rented premises</a> in the neat and clean condition and no such work will be done which may damage or prejudicially affect any party of the said rented premises.</p>
<p>4. That the second party can not make an additional/alteration in the said premises without the written permission of the first party nor they can sublet/part of the premises to any person and not to share or sublet the accommodation with outside strictly.</p>
<p>5. That the second party/tenant shall allow the first party or his authorized agents to enter upon the premises and inspect the condition thereof at all reasonable time during the occupation.</p>
<p>6. That in case of the defaults for non-payment of the rent the first party shall be fully/entitled to realize the rent through the court of law, under specific performance of the contract at the cost, risk and responsibility of the second party.</p>
<p>7. That either party can terminate the agreement at any stage during the course of this agreement by giving notice to the other party at least 1 month in advance.</p>
<p>8. That this agreement is only for a period of 11 months w.e.f <input class="input-line" type="text" value="" name="">to <input class="input-line" type="text" value="" name=""> and on the completion of 11 months the possession of the property shall automatically revert back to the party of the first part, unless there has been a fresh agreement which has been put down in writing to which both parties have given their written consent.</p>
<p>9. That at the time of vacation of the said rented premises to the first party, shall be in safe and sound condition with all fitting/fixtures as aforesaid intact. In case of any damage or injury is found to be done to the rented premises or any fitting/fixture installed therein, the cost thereof shall be charged by the first party from the second party and if any arrears of electricity or other services charges or rent as such is found to be arrears at the time of vacation of the said rented portion, the same shall be recovered by the first party from the second party.</p>
<p>IN WITNESSES WHEREOF both the parties have set their respective hands on this agreement, at Delhi, on the day, month and year, first written above in the presence of the following witnesses.</p>
<p>WITNESSES:</p>
<p>FIRST PARTY<br>
SECOND PARTY</p>
<p>Format of Lease Deed Residential Property<br>
Residential Property Lease Deed Draft</p> 
 
</form> 
</body>
</html>