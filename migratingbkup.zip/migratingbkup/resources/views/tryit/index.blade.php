
<!DOCTYPE html>
<html>
<head>
  <title>Create Application html file here</title>
  <script type="text/javascript" src="js/tryit.js"></script>
  <link rel="shortcut icon" href="#">
</head>

<frameset resizable="yes" rows="50%,*%" onload="init();">
  <frame name="editbox" src="javascript:'';">
  <frame name="dynamicframe" src="javascript:'';"> 

</frameset>


</html>

