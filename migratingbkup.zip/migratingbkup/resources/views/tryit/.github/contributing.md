## Contributing

Please note that this project is released with a [Contributor Code of Conduct](code-of-conduct.md). By participating in this project you agree to abide by its terms.

## Important
Make sure you keep the website static, no npm packages or Javascript frameworks, if you follow that, you are good to go.
