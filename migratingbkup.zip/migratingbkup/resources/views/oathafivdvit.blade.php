<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <style>
     p{
	     line-height: 24px;
	 }
	 .input-line:focus{
	   outline:none;
	 }
	 .input-line{
	   border:none;
	   border-bottom:1px solid #000;
	 }
	 .input-width{
	    width:33%;
	 }
   </style>
</head>
<body>
 <form class="guarantee-form" name="_form">
  @foreach($records as $record)
<h2>AFFIDAVIT TO BE SUBMITTED WITH THE APPLICATION TO THE REGIONAL TRANSPORT AUTHORITY FOR ISSUANCE OF DUPLICATE DRIVING LICENCE.</h2>



<p>Before the Regional Transport Officer, {{$record->place}}, (Name of Place). </p>
<p>Affidavit of Mr./Ms.{{$record->name}},S/o./D/o., Sh.{{$record->gaurdian}} aged{{$record->age}} years, Resident of {{$record->resident}} .</p>
<p>I, the above named deponent, solemnly affirm and state as under:</p>
<p>1. That I am the applicant in the application for the issue of duplicate driving licence and as such fully conversant with the facts deposed to below. </p>
<p>2. That I was issued driving licence no.{{$record->licenseno}}on  by your office to drive Scooter and Jeep with gears. </p>
<p>3. That my driving licence no.lost{{$record->lostlicenseno}} has been lost on or about{{$record->lostplace}}, for which I have lodged FIR with Police Station, {{$record->policestation}}vide FIR No. {{$record->firno}} dated{{$record->reg_date}}. </p>
<p>4. That I have not deposited the said driving license with any Court or any other public authority. </p>
<p>5. That my licence has not been cancelled and no charge sheet has been filed against me for any offence under the Motor Vehicles Act or Rules made thereunder or any other law for the time being in force. </p>
<p>6. That I am otherwise qualified to hold the driving licence.</p>
<p>7. That if the original licence will be found, I undertake to deposit the same with your office. </p>
<p>8.That in view of the above, it is necessary that duplicate driving licence be issued to me. </p>
<p>DEPONENT</p>
<p>Signed at {{$record->signedplace}}this{{$record->affivdavit}}day of{{$record->day}}, </p>
<p><u>VERIFICATION</u></p>
<p>I, {{$record->verifier}}the above named deponent do hereby verify on oath that the contents of the affidavit above are true to my personal knowledge and nothing material has been concealed or falsely stated. Verified at{{$record->verifierplace}} this {{$record->doc}} day of {{$record->verifierday}}</p>
<p>DEPONENT</p>
 @endforeach
 </form> 
</body>
</html>