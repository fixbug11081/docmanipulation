<form method="POST" action="http://localhost:8002/generate/rent-agreement" accept-charset="UTF-8"><input name="_token" type="hidden" value="0EJ4d7A8NET9iiRvUY1MEqFHdsDJEUpXWguaI0sq">


<label for="First Party">First Party</label>
<input name="firstparty" type="text">
<br><label for="Second Party">Second Party</label>
<input name="secondparty" type="text">
<br><label for="Address">Address</label>
<input name="address" type="text">
<br><label for="Date of Agreement">Date Of Agreement</label>
<input name="dateofagreement" type="text">
<br><label for="Rent Amount">Rent Amount</label>
<input name="rentamount" type="text">
<br><label for="Years">Years</label>
<input name="yearsofagreement" type="text">
<br>
<input class="submit" name="submit" type="submit" value="submit">

</form>