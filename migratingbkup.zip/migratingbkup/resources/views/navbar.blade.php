<!-- Navigation -->

<nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
	<!-- Text Logo - Use this if you don't have a graphic logo -->
	<!-- <a class="navbar-brand logo-text page-scroll" href="index.html">Evolo</a> -->

	<!-- Image Logo -->
	<!--<a class="navbar-brand logo-image" href="/">-->
	   <a href="/" style="text-decoration:none;">
	       <h1>DocMaster</h1>
	   </a>    
	    <!--<img src="images/logo.svg" alt="alternative">-->
	   <!--</a>-->

	<div class="collapse navbar-collapse" id="navbarsExampleDefault">
		<ul class="navbar-nav ml-auto">
		    <li class="nav-item">
				<a class="nav-link page-scroll" href="/login">Login</a>
			</li>
			<li class="nav-item">
				<a class="nav-link page-scroll" href="/faq" target="_blank">FAQ</a>
			</li>
			<li class="nav-item" >
				<a class="nav-link page-scroll" href="/complaint-home" >Complaint</a>
			</li>	
		
           	
		</ul>
		
	</div>
</nav> <!-- end of navbar -->
	<!-- end of navigation -->