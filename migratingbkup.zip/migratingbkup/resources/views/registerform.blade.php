
{{Form::open(["url"=>"/save-applicant", "method"=>"post"])}}

{{Form::label('Applicant Form')}}
{{Form::label('Name')}}
{{Form::text('name')}}
{{Form::token()}}
<?php echo "<br>"; ?>
{{Form::label('Gender')}}
{{Form::text('gender')}}

<?php echo "<br>"; ?>
{{Form::label('Gaurdian')}}
{{Form::text('gaurdian')}}

<?php echo "<br>"; ?>
{{Form::label('Address')}}
{{Form::text('address')}}

	<?php echo "<br>"; ?>
{{Form::label('Date of birth')}}
{{Form::text('dob')}}
	<?php echo "<br>"; ?>
{{Form::submit('submit', ['name'=>'submit', 'class'=>'submit' ])}}

{{Form::close()}}

