<form method="POST" action="http://localhost:8000/generate/college-form" accept-charset="UTF-8"><input name="_token" type="hidden" value="todn4T4itGItvVsGYfTBTdLuLQRNpcyfrvtGbTox">

<label for="Name">Name</label>
<input name="name" type="text">
<br><label for="Address">Address</label>
<input name="address" type="text">
<br><label for="Course">Course</label>
<input name="course" type="text">
<br>
<input class="submit" name="submit" type="submit" value="submit">

</form>