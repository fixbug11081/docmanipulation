"""
<b>ticket template</b><code>
{{$record->form}}
</code>{{$record->test}}{{$record->test}}
"""