
<!DOCTYPE html>
<html>
<head>
<title>DocMaster</title>
<style>
    .container {margin:0 auto;color:#626262;font:400 1rem/1.5rem "Raleway", sans-serif;}

    /* Style the buttons that are used to open and close the accordion panel */
.accordion {
  background-color: #00BFD8;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  text-align: left;
  border: none;
  outline: none;
  transition: 0.4s;
}
.accordion p {color: #fff;margin:0;padding:0;width:92%;display:inline-block;font:400 1rem/1.5rem "Raleway", sans-serif;}

/* Add a background color to the button if it is clicked on (add the .active class with JS), and when you move the mouse over it (hover) */
.active, .accordion:hover {
  background-color: #00A0B5;
}

/* Style the accordion panel. Note: hidden by default */
.panel {
  padding: 5px 18px;
  background-color: #f5f5f5;
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.2s ease-out;
  width:100%;
}
.panel p, .panel ul {padding-top:15px;}
.accordion:after {
  content: '\02795'; /* Unicode character for "plus" sign (+) */
  font-size: 13px;
  color: #fff;
  float: right;
  margin-left: 5px;
}

.active:after {
  content: "\2796"; /* Unicode character for "minus" sign (-) */
}
.navbar.navbar-custom {background-color:#fff;box-shadow:0 0.0625rem 0.375rem 0 rgba(0, 0, 0, 0.1);padding:0.5rem 5rem 0.5rem 5rem;}
.faq-content {padding-top: 120px;}
</style>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="Repo Builder - Create application hasless filled form.">
    <meta name="author" content="Inovatik">

    <!-- OG Meta Tags to improve the way the post looks when you share the page on LinkedIn, Facebook, Google+ -->
  <meta property="og:site_name" content="" /> <!-- website name -->
  <meta property="og:site" content="" /> <!-- website link -->
  <meta property="og:title" content=""/> <!-- title shown in the actual shared post -->
  <meta property="og:description" content="" /> <!-- description shown in the actual shared post -->
  <meta property="og:image" content="" /> <!-- image link, make sure it's jpg -->
  <meta property="og:url" content="" /> <!-- where do you want your post to link to -->
  <meta property="og:type" content="article" />

    <!-- Website Title -->
    <title>Repo Builder - Create Application hasless Filled Form</title>
    
    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,600,700,700i&amp;subset=latin-ext" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="css/swiper.css" rel="stylesheet">
  <link href="css/magnific-popup.css" rel="stylesheet">
  <link href="css/styles.css" rel="stylesheet">
  
  <!-- Favicon  -->
    <link rel="icon" href="images/favicon.png">
</head>
<body>
    <!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
	<!-- Text Logo - Use this if you don't have a graphic logo -->
	<!-- <a class="navbar-brand logo-text page-scroll" href="index.html">Evolo</a> -->

	<!-- Image Logo -->
	<!--<a class="navbar-brand logo-image" href="/">-->
	   <a href= "/" style="text-decoration:none">
	       <h1> DocMaster</h1>
	   </a>    
	    <!--<img src="images/logo.svg" alt="alternative">-->
	   <!--</a>-->

	<div class="collapse navbar-collapse" id="navbarsExampleDefault">
		<ul class="navbar-nav ml-auto">
		    <li class="nav-item">
				<a class="nav-link page-scroll" href="/login">Login</a>
			</li>
			<li class="nav-item">
				<a class="nav-link page-scroll" href="/faq" target="_blank">FAQ</a>
			</li>

		</ul>
		
	</div>
</nav> <!-- end of navbar -->
	<!-- end of navigation -->
	
	<section id="faq" class="faq mb-5">
        <div class="faq-content">
            <div class="container">
                <div class="row">
    <h3 class="m-auto pb-4">Frequently Asked Questions</h3>
    
    <button class="accordion"><p>1.Is it paid or free services?</p></button>
<div class="panel">
  <p>It free for 30 days ,then can choose premium plan</p>
</div>

<button class="accordion"><p>2.I do not find my desire template?</p></button>
<div class="panel">
  <p>Please email the link or document to emailid:ajeet@webappmate.com</p> 
</div>

<button class="accordion"><p>3.How it works?</p></button>
<div class="panel">
  <ul>
<li>Select the form need to filled.</li> 
<li>Filled the data in selected form.</li>
<li>Get the Form template with your given data.</li>
<li>Change the template design for user.</li>
<li>Take the print / Save the file in ms document/See the preview in pdf/Save the pdf.</li>
</ul>
</div>
<button class="accordion"><p>4.Which extension of document this platform support?</p></button>
<div class="panel">
  <p>Extensions are .pdf,.docx.</p>
</div>
<button class="accordion"><p>5.Is preview available for documents?</p></button>
<div class="panel">
  <p>Yes</p>
</div>
</div>
</div>
</div>
</section>
<script>
 var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    }
  });
}
</script>

</body>
</html>