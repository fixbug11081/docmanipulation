<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <style>
     p{
	     line-height: 24px;
	 }
	 .input-line:focus{
	   outline:none;
	 }
	 .input-line{
	   border:none;
	   border-bottom:1px solid #000;
	 }
	 .input-width{
	    width:33%;
	 }
	 .spanborder-bottom{
       border-bottom:1px solid #000;
	 }
   </style>
</head>

<body>
<div id="source-html">
<form class="guarantee-form" name="_form">

@foreach($records as $record)
<h3>Senior Citizen Certificate</h3>

Shri/Smt. {{$record->name}} is here to certify that {{$record->age}} 

is considering as senior citizen and he is eligible for all benifit by government.


 @endforeach
</form> 
</div>


</body>
</html><p>sfsfsfsfsfsfsdfsfsfsf</p>