<b>ticket template</b>
<code>&#123;&#123; $recode-&gt;&#125; &#125;
	</code>

<b>ticket template</b>
<code>&#123;&#123; $recode-&gt;html&#125;&#125;
	</code>
czxczxczxczxc