<p>@foreach($records as $record)</p>

<h3>Office Duty</h3>

<p>Government has decide new duty on office {{$record-&gt;name}} with address {{$record-&gt;address}} @endforeach</p>