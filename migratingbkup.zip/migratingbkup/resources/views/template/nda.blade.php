<p><strong>**Please note this is a template and you should consult with counsel**</strong></p>

<p>&nbsp;</p>

<p><strong>{companyname}</strong></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p><strong>BETWEEN</strong></p>

<p>&nbsp;</p>

<p>1. <strong>{companyname}</strong><strong>, </strong>(the &quot;Disclosing Party&quot;); and</p>

<p>&nbsp;</p>

<p>2. <strong>{name}</strong><strong>, </strong>(the &quot;Receiving Party&quot;),</p>

<p>&nbsp;</p>

<p>Collectively referred to as the &quot;Parties&quot;.</p>

<p>&nbsp;</p>

<p><strong>RECITALS</strong></p>

<p>I{name} understands that <strong>{companyname}</strong> (a &hellip;.. Corporation) has disclosed or may disclose information relating to <strong>{companyname}</strong> business, which to the extent previously, presently, or subsequently disclosed to is hereinafter referred to as &quot;Proprietary Information&quot; of <strong>{companyname}</strong>.</p>

<p>&nbsp;</p>

<p><strong>OPERATIVE PROVISIONS</strong></p>

<p>&nbsp;</p>

<p>1. In consideration of the disclosure of Proprietary Information by <strong>{companyname}</strong>, {name} hereby agree:</p>

<p>&nbsp;</p>

<p>(i) To hold the Proprietary Information in strict confidence and to take all reasonable precautions to protect such Proprietary Information (including, without limitation, all precautions the Receiving Party employs with respect to its own confidential materials);</p>

<p>&nbsp;</p>

<p>(ii) Not to disclose any such Proprietary Information or any information derived therefrom to any third person;</p>

<p>&nbsp;</p>

<p>(iii) Not to make any use whatsoever at any time of such Proprietary Information except to evaluate internally its relationship with <strong>{companyname}</strong>, and;</p>

<p>&nbsp;</p>

<p>(iv) Not to copy or reverse engineer any such Proprietary Information. The Receiving Party shall procure that its employees, agents and subcontractors to whom Proprietary Information is disclosed or who have access to Proprietary Information sign a nondisclosure or similar agreement in content substantially similar to this Agreement.</p>

<p>&nbsp;</p>

<p>2. Immediately upon the written request by <strong>{companyname}</strong> at any time, {name} will return to {companyname}all Proprietary Information and all documents or media containing any such Proprietary Information and any and all copies or extracts thereof, save that where such Proprietary Information is a form incapable of return or has been copied or transcribed into another document, it shall be destroyed or erased, as appropriate.</p>

<p>&nbsp;</p>

<p>3.{companyname} may make disclosures required by law or court order provided that {name}uses diligent reasonable efforts to limit disclosure and has allowed the <strong>{companyname}</strong> to seek a protective order.</p>

<p>&nbsp;</p>

<p>4. {name} understands that nothing herein:</p>

<p>&nbsp;</p>

<p>(i) Requires the disclosure of any Proprietary Information or;</p>

<p>&nbsp;</p>

<p>(ii) Requires the Disclosing Party to proceed with any transaction or relationship.</p>

<p>&nbsp;</p>

<p>5. {name} agrees to not compete as a direct business with <strong>{companyname}</strong> for the next two years. A direct competitor will be considered a website powered as a business social network.</p>

<p>&nbsp;</p>

<p>6. The failure of either party to enforce its rights under this Agreement at any time for any period shall not be construed as a waiver of such rights. If any part, term or provision of this Agreement is held to be illegal or unenforceable neither the validity, nor enforceability of the remainder of this Agreement shall be affected.</p>

<p>&nbsp;</p>

<p>7. Neither Party shall assign or transfer all or any part of its rights under this Agreement without the consent of the other Party. This Agreement may not be amended for any other reason without the prior written agreement of both Parties. This Agreement constitutes the entire understanding between the Parties relating to the subject matter hereof unless any representation or warranty made about this Agreement was made fraudulently and, save as may be expressly referred to or referenced herein, supersedes all prior representations, writings, negotiations or understandings with respect hereto.</p>

<p>&nbsp;</p>

<p>8. This Agreement shall be governed by the laws of the jurisdiction in which <strong>{companyname}</strong>is located, the State of___{state}_________, and the parties agree to submit disputes arising out of or in connection with this Agreement to the non-exclusive of the courts in the Territory.</p>

<p>&nbsp;</p>

<p>{companyname}</p>

<p><strong>{name}</strong></p>

<p><strong>{address}</strong></p>

<p>{date}</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>{companyname}</p>

<p>{representative}</p>

<p>{address}</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p><strong>{date}</strong></p>

<p>&nbsp;</p><p><strong>**Please note this is a template and you should consult with counsel**</strong></p>

<p>&nbsp;</p>

<p><strong>{companyname}</strong></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p><strong>BETWEEN</strong></p>

<p>&nbsp;</p>

<p>1. <strong>{companyname}</strong><strong>, </strong>(the &quot;Disclosing Party&quot;); and</p>

<p>&nbsp;</p>

<p>2. <strong>{name}</strong><strong>, </strong>(the &quot;Receiving Party&quot;),</p>

<p>&nbsp;</p>

<p>Collectively referred to as the &quot;Parties&quot;.</p>

<p>&nbsp;</p>

<p><strong>RECITALS</strong></p>

<p>I{name} understands that <strong>{companyname}</strong> (a &hellip;.. Corporation) has disclosed or may disclose information relating to <strong>{companyname}</strong> business, which to the extent previously, presently, or subsequently disclosed to is hereinafter referred to as &quot;Proprietary Information&quot; of <strong>{companyname}</strong>.</p>

<p>&nbsp;</p>

<p><strong>OPERATIVE PROVISIONS</strong></p>

<p>&nbsp;</p>

<p>1. In consideration of the disclosure of Proprietary Information by <strong>{companyname}</strong>, {name} hereby agree:</p>

<p>&nbsp;</p>

<p>(i) To hold the Proprietary Information in strict confidence and to take all reasonable precautions to protect such Proprietary Information (including, without limitation, all precautions the Receiving Party employs with respect to its own confidential materials);</p>

<p>&nbsp;</p>

<p>(ii) Not to disclose any such Proprietary Information or any information derived therefrom to any third person;</p>

<p>&nbsp;</p>

<p>(iii) Not to make any use whatsoever at any time of such Proprietary Information except to evaluate internally its relationship with <strong>{companyname}</strong>, and;</p>

<p>&nbsp;</p>

<p>(iv) Not to copy or reverse engineer any such Proprietary Information. The Receiving Party shall procure that its employees, agents and subcontractors to whom Proprietary Information is disclosed or who have access to Proprietary Information sign a nondisclosure or similar agreement in content substantially similar to this Agreement.</p>

<p>&nbsp;</p>

<p>2. Immediately upon the written request by <strong>{companyname}</strong> at any time, {name} will return to {companyname}all Proprietary Information and all documents or media containing any such Proprietary Information and any and all copies or extracts thereof, save that where such Proprietary Information is a form incapable of return or has been copied or transcribed into another document, it shall be destroyed or erased, as appropriate.</p>

<p>&nbsp;</p>

<p>3.{companyname} may make disclosures required by law or court order provided that {name}uses diligent reasonable efforts to limit disclosure and has allowed the <strong>{companyname}</strong> to seek a protective order.</p>

<p>&nbsp;</p>

<p>4. {name} understands that nothing herein:</p>

<p>&nbsp;</p>

<p>(i) Requires the disclosure of any Proprietary Information or;</p>

<p>&nbsp;</p>

<p>(ii) Requires the Disclosing Party to proceed with any transaction or relationship.</p>

<p>&nbsp;</p>

<p>5. {name} agrees to not compete as a direct business with <strong>{companyname}</strong> for the next two years. A direct competitor will be considered a website powered as a business social network.</p>

<p>&nbsp;</p>

<p>6. The failure of either party to enforce its rights under this Agreement at any time for any period shall not be construed as a waiver of such rights. If any part, term or provision of this Agreement is held to be illegal or unenforceable neither the validity, nor enforceability of the remainder of this Agreement shall be affected.</p>

<p>&nbsp;</p>

<p>7. Neither Party shall assign or transfer all or any part of its rights under this Agreement without the consent of the other Party. This Agreement may not be amended for any other reason without the prior written agreement of both Parties. This Agreement constitutes the entire understanding between the Parties relating to the subject matter hereof unless any representation or warranty made about this Agreement was made fraudulently and, save as may be expressly referred to or referenced herein, supersedes all prior representations, writings, negotiations or understandings with respect hereto.</p>

<p>&nbsp;</p>

<p>8. This Agreement shall be governed by the laws of the jurisdiction in which <strong>{companyname}</strong>is located, the State of___{state}_________, and the parties agree to submit disputes arising out of or in connection with this Agreement to the non-exclusive of the courts in the Territory.</p>

<p>&nbsp;</p>

<p>{companyname}</p>

<p><strong>{name}</strong></p>

<p><strong>{address}</strong></p>

<p>{date}</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>{companyname}</p>

<p>{representative}</p>

<p>{address}</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p><strong>{date}</strong></p>

<p>&nbsp;</p><p>&nbsp;</p>

<p>&nbsp;</p>

<p><strong>{companyname}</strong></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p><strong>BETWEEN</strong></p>

<p>&nbsp;</p>

<p>1. <strong>{companyname}</strong><strong>, </strong>(the &quot;Disclosing Party&quot;); and</p>

<p>&nbsp;</p>

<p>2. <strong>{name}</strong><strong>, </strong>(the &quot;Receiving Party&quot;),</p>

<p>&nbsp;</p>

<p>Collectively referred to as the &quot;Parties&quot;.</p>

<p>&nbsp;</p>

<p><strong>RECITALS</strong></p>

<p>I{name} understands that <strong>{companyname}</strong> (a &hellip;.. Corporation) has disclosed or may disclose information relating to <strong>{companyname}</strong> business, which to the extent previously, presently, or subsequently disclosed to is hereinafter referred to as &quot;Proprietary Information&quot; of <strong>{companyname}</strong>.</p>

<p>&nbsp;</p>

<p><strong>OPERATIVE PROVISIONS</strong></p>

<p>&nbsp;</p>

<p>1. In consideration of the disclosure of Proprietary Information by <strong>{companyname}</strong>, {name} hereby agree:</p>

<p>&nbsp;</p>

<p>(i) To hold the Proprietary Information in strict confidence and to take all reasonable precautions to protect such Proprietary Information (including, without limitation, all precautions the Receiving Party employs with respect to its own confidential materials);</p>

<p>&nbsp;</p>

<p>(ii) Not to disclose any such Proprietary Information or any information derived therefrom to any third person;</p>

<p>&nbsp;</p>

<p>(iii) Not to make any use whatsoever at any time of such Proprietary Information except to evaluate internally its relationship with <strong>{companyname}</strong>, and;</p>

<p>&nbsp;</p>

<p>(iv) Not to copy or reverse engineer any such Proprietary Information. The Receiving Party shall procure that its employees, agents and subcontractors to whom Proprietary Information is disclosed or who have access to Proprietary Information sign a nondisclosure or similar agreement in content substantially similar to this Agreement.</p>

<p>&nbsp;</p>

<p>2. Immediately upon the written request by <strong>{companyname}</strong> at any time, {name} will return to {companyname}all Proprietary Information and all documents or media containing any such Proprietary Information and any and all copies or extracts thereof, save that where such Proprietary Information is a form incapable of return or has been copied or transcribed into another document, it shall be destroyed or erased, as appropriate.</p>

<p>&nbsp;</p>

<p>3.{companyname} may make disclosures required by law or court order provided that {name}uses diligent reasonable efforts to limit disclosure and has allowed the <strong>{companyname}</strong> to seek a protective order.</p>

<p>&nbsp;</p>

<p>4. {name} understands that nothing herein:</p>

<p>&nbsp;</p>

<p>(i) Requires the disclosure of any Proprietary Information or;</p>

<p>&nbsp;</p>

<p>(ii) Requires the Disclosing Party to proceed with any transaction or relationship.</p>

<p>&nbsp;</p>

<p>5. {name} agrees to not compete as a direct business with <strong>{companyname}</strong> for the next two years. A direct competitor will be considered a website powered as a business social network.</p>

<p>&nbsp;</p>

<p>6. The failure of either party to enforce its rights under this Agreement at any time for any period shall not be construed as a waiver of such rights. If any part, term or provision of this Agreement is held to be illegal or unenforceable neither the validity, nor enforceability of the remainder of this Agreement shall be affected.</p>

<p>&nbsp;</p>

<p>7. Neither Party shall assign or transfer all or any part of its rights under this Agreement without the consent of the other Party. This Agreement may not be amended for any other reason without the prior written agreement of both Parties. This Agreement constitutes the entire understanding between the Parties relating to the subject matter hereof unless any representation or warranty made about this Agreement was made fraudulently and, save as may be expressly referred to or referenced herein, supersedes all prior representations, writings, negotiations or understandings with respect hereto.</p>

<p>&nbsp;</p>

<p>8. This Agreement shall be governed by the laws of the jurisdiction in which <strong>{companyname}</strong>is located, the State of___{state}_________, and the parties agree to submit disputes arising out of or in connection with this Agreement to the non-exclusive of the courts in the Territory.</p>

<p>&nbsp;</p>

<p>{companyname}</p>

<p><strong>{name}</strong></p>

<p><strong>{address}</strong></p>

<p>{date}</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>{companyname}</p>

<p>{representative}</p>

<p>{address}</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p><strong>{date}</strong></p>

<p>&nbsp;</p>