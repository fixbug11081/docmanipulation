<p>@foreach($records as $record)</p>

<h3>Road Tax</h3>

<p>Road with name {{$record->roadname}} is having road number {{$record->roadno}} f. @endforeach</p>