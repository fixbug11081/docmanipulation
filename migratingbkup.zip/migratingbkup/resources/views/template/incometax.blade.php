<p>@foreach($records as $record)</p>

<h3>Income tax</h3>

<p>Government has decide new duty on office {{$record->gross}} with address {{$record->salary}} @endforeach</p>{{$record->tax}}