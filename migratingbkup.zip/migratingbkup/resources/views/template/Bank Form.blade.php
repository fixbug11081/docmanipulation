<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <style>
     p{
       line-height: 24px;
   }
   .input-line:focus{
     outline:none;
   }
   .input-line{
     border:none;
     border-bottom:1px solid #000;
   }
   .input-width{
      width:33%;
   }
   .spanborder-bottom{
       border-bottom:1px solid #000;
   }
   </style>
</head>

<body>
<div id="source-html">
<form class="guarantee-form" name="_form">

@foreach($records as $record)
<h3>Suggested Bank Guarantee Format</h3>

<p>We <span class="spanborder-bottom">{{$record->firstpartyname}}</span> issue in favour of <span class="spanborder-bottom">{{$record->secondpartyname}}</span>hereinafter ‘called as<br>
We the Bank<span class="spanborder-bottom">{{$record->bankname}}</span>do hereby undertake to pay Rs<span class="spanborder-bottom">{{$record->gaurentedproperty}}</span>against loss or damage caused to or suffered by the said by reason of any breach by</p>
<p>We the Bank of India do hereby undertake to pay the amounts due and payable under this guarantee without any demur, merely on demand, however, our liability under this guarantee shall be restricted to an amount not exceeding Rs.gaurentee <span class="spanborder-bottom">{{$record->gaurentee}}</span></p>

<p>We the Bank of India further agree that the guarantee herein contained shall remain in full force and effect till released by the said Authority We the Bank lastly undertake not to revoke this guarantee during its currency except with previous consent of the Authority in writing.</p>

<p>Notwithstanding anything contained herein. before, our liability under his guarantee is restricted to Rs.<span class="spanborder-bottom">{{$record->amount}}<span>Only) and our guarantee should remain in full force until and unless a suit or an action in writing under the guarantee is filed against us on and after this date all rights under the said guarantee shall be forfeited and we shall be released and discharged from liabilities thereunder.</p>

<p>DATED <span class="spanborder-bottom">{{$record->date}}</span> AT <span class="spanborder-bottom">{{$record->place}}</span> FOR BANK</p>

<p>Notwithstanding anything contained herein before</p>

<p>1. Our liability under this Bank guarantee shall not exceed Rs.<span class="spanborder-bottom">{{$record->gaurentedamount}}</span> (Rupees 
2. This bank Guarantee shall be valid upto <span class="spanborder-bottom">{{$record->expirydate}}</span><br>
3. We are liable to pay the guarantee amount or any part thereof under this Bank Guarantee only and only. If <span class="spanborder-bottom">{{$record->serveamount}}</span> serve upon us a written claim or demand on or before<span class="spanborder-bottom">{{$record->servedate}}</span>.<br>
1. All claims under this guarantee shall be payable at New Delhi.<br>
2. This Guarantee will be returned to us as soon as the purpose for which its is issued is fulfilled.<br>
3. The Bank Guarantee confirmation No. <span class="spanborder-bottom">{{$record->gaurentyid}}</span>shall be mentioned in the records.</p> 
 @endforeach
</form> 
</div>


</body>
</html>

<p><strong>your name is _______.Age is now ______.Get fresh air in city _______.</strong></p>