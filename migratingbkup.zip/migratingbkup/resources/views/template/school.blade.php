<p>sfsfsfsfsffsfsf sfsdfsfsf sfsfsfsfsssfsf</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>{{$test-&gt;record}}</p>