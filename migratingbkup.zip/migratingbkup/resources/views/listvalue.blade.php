<!DOCTYPE>
<html>
<body>
<table>
  
	<tr>

		@foreach($cols as $col)
		<th>{{$col->COLUMN_NAME}}</th>
		@endforeach
    </tr>
    <tr border="2">
    	<?php $datas =  json_decode(json_encode($records),true);?>
    			<?php foreach ($datas[0] as $key => $value) {?>
    				<td border="2"><?php echo $value;?></td>

    			<?php }?>
    			<td href="/download">Downloads</td>
    </tr>
</table> 
<body>   		
<html>

