  <!DOCTYPE html>
  <html lang="en">

  <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- SEO Meta Tags -->
  <meta name="description" content="Create a stylish landing page for your business startup and get leads for the offered services with this HTML landing page template.">
  <meta name="author" content="Inovatik">
  <!-- OG Meta Tags to improve the way the post looks when you share the page on LinkedIn, Facebook, Google+ -->
  <meta property="og:site_name" content="" />
  <!-- website name -->
  <meta property="og:site" content="" />
  <!-- website link -->
  <meta property="og:title" content="" />
  <!-- title shown in the actual shared post -->
  <meta property="og:description" content="" />
  <!-- description shown in the actual shared post -->
  <meta property="og:image" content="" />
  <!-- image link, make sure it's jpg -->
  <meta property="og:url" content="" />
  <!-- where do you want your post to link to -->
  <meta property="og:type" content="article" />
  <!-- Website Title -->
  <title>Docmaster - Form builder and templating </title>
  <!-- Styles -->
  <link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,600,700,700i&amp;subset=latin-ext" rel="stylesheet">
  <link href="css/bootstrap.css" rel="stylesheet">
  <link href="css/fontawesome-all.css" rel="stylesheet">
  <link href="css/swiper.css" rel="stylesheet">
  <link href="css/magnific-popup.css" rel="stylesheet">
  <link href="css/styles.css"rel="stylesheet">
  <!-- Favicon  -->
  <link rel="icon" href="images/favicon.png">
  <style>
    .hide-select{
         display:none;
    }
    .border-color{
        border:1px solid #ccc; 
    }
    page {
      background: white;
      display: block;
      margin: 0 auto;
      margin-bottom: 0.5cm;
      box-shadow: 0 0 0.5cm rgba(0,0,0,0.5);
    }
    A4 {  
      width: 21cm;
      height: 29.7cm; 
    }
    @media print {
          body * {
            visibility: hidden;
          }
          #printSection,
          #printSection * {
            visibility: visible;
          }
          #printSection {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: yellow;
          }
        }

    
  </style>
  </head>

  <body data-spy="scroll" data-target=".fixed-top">
  <!-- Preloader -->
  <!-- end of preloader -->
  <!-- Navigation -->
 @include('navbar')
  <!-- end of navbar -->
  <!-- end of navigation -->
  <!-- tools -->
  <div id="" class="grayFormSec">
  <div class="container">
    <div class="box12">
         @if($btnflag == 0)
        <h2><label>Editor Tool<label></h2>
         @else
         <h2><label>Document<label></h2>
         @endif
        <div class="form-group">
            <form action="/edit/file" method="post">
               
                    @if($btnflag == 0)
                     <div class="row bg-white">
                    <div class="col-lg-6">
                        <span>
                        <a href="#" data-toggle="tooltip" title="Edit the text format of predefined template with the values, Click the Save button to finalise text"> 
                            <textarea id='contentid' name=textcontent rows=20 cols=100 style='resize:vertical'>{{$htmlfile}}</textarea>
                        </a></span>
                    </div>
                    <div class="col-lg-6 gaurantee-formate">
                         <span>
                        <a href="#" data-toggle="tooltip" class="info-tootip" title="Final text format as output "> 
                        <div name="doc"    id="doc"></div>    
                         </a></span>
                       
                    @else
                    <div class="row ">
                    <div class="col-lg-6 hide-select">
                        <span>
                        <a href="#" data-toggle="tooltip" class="info-tootip" title="Edit the text format of predefined template with the values, Click the Save button to finalise text"> 
                        <textarea id='contentid' name=textcontent rows=20 cols=100 style='resize:vertical'>{{$htmlfile}}</textarea>
                        </a></span>                        
                    </div>
                     <div class="col-lg-6 gaurantee-formate offset-lg-3">
                        <span>
                        <a href="#" data-toggle="tooltip"
                        class="info-tootip"
                        title="Edit the text format of predefined template with the values, Click the Save button to finalise text"> 
                         
                          <div name="doc" id="doc" class="border-color"></div>
                         </a></span> 
                    @endif
                   
                    
                    </div>
                    <div class="modal fade" id="previewModal">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <!-- Modal Header -->
                                <div class="modal-header">
                                    <h4 class="modal-title">PDF Template</h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>
                                <!-- Modal body -->
                                <div class="modal-body">
                                    <div id="pdftext"  class="page A4"></div>
                                </div>
                                <!-- Modal footer -->
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
     
       <!-- <button type="button" onclick="htmlrender()" value="Document" class="btn-solid-lg btn">Document</button>-->
        @if($btnflag == 0)
        <span>
        <a href="#" data-toggle="tooltip" title="Export MS Word document"> 
        <button type="button" onclick="exportHTML();" value="Downloads" class="btn-solid-lg btn">MS Word</button>
        </a>
        </span>
        <span>
        <a href="#" data-toggle="tooltip" title="Preview the PDF document"> 
        <button type="button" value="Preview" class="btn-solid-lg btn" onclick="previewPDF();">Preview PDF</button>
        </span>
         <span>
        <a href="#" data-toggle="tooltip" title="Export the PDF format document"> 
        <button type="button" onclick="exportPDF();" value="PDF" class="btn-solid-lg btn">PDF Downloads</button>
        </span>
        <span>
        <a href="#" data-toggle="tooltip" title="Save the text after changing the format in second panel"> 
        <button type="button" onclick="save()" value="Save" class="btn-solid-lg btn">Save</button>
        </span>
        <span>
        <a href="#" data-toggle="tooltip" title="Take the print of text in Second Panel"> 
        <button type="button" onclick="docPrint();" class="btn-solid-lg btn">Print</button>
        </span>
        @else
        <div class="offset-lg-3">
        <button type="button" onclick="save()" value="Save" class="btn-solid-lg btn">Save</button>
        <button type="button" onclick="docPrint();" class="btn-solid-lg btn">Print</button>
        </div>
        @endif
    </div>
    <!-- end of col -->
  </div>
  <!-- end of container custom-form-inline" -->
  </div>
  <!-- end of form-1 -->
  <!-- end of request -->
  <!-- Footer -->
  <div class="footer">
  <div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="footer-col">
                <h4>About Evolo</h4>
                <p>We're passionate about offering some of the best business growth services for startups</p>
            </div>
        </div>
        <!-- end of col -->
        <div class="col-md-4">
            <div class="footer-col middle">
                <h4>Important Links</h4>
                <ul class="list-unstyled li-space-lg">
                    <li class="media"> <i class="fas fa-square"></i>
                        <div class="media-body">Our business partners <a class="turquoise" href="#your-link">startupguide.com</a>
                        </div>
                    </li>
                    <li class="media"> <i class="fas fa-square"></i>
                        <div class="media-body">Read our <a class="turquoise" href="terms-conditions.html">Terms & Conditions</a>, <a class="turquoise" href="privacy-policy.html">Privacy Policy</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <!-- end of col -->
       <!-- <div class="col-md-4">
            <div class="footer-col last">
                <h4>Social Media</h4>
                <span class="fa-stack">
      <a href="#your-link">
        <i class="fas fa-circle fa-stack-2x"></i>
        <i class="fab fa-facebook-f fa-stack-1x"></i>
      </a>
    </span>
                <span class="fa-stack">
      <a href="#your-link">
        <i class="fas fa-circle fa-stack-2x"></i>
        <i class="fab fa-twitter fa-stack-1x"></i>
      </a>
    </span>
                <span class="fa-stack">
      <a href="#your-link">
        <i class="fas fa-circle fa-stack-2x"></i>
        <i class="fab fa-google-plus-g fa-stack-1x"></i>
      </a>
    </span>
                <span class="fa-stack">
      <a href="#your-link">
        <i class="fas fa-circle fa-stack-2x"></i>
        <i class="fab fa-instagram fa-stack-1x"></i>
      </a>
    </span>
                <span class="fa-stack">
      <a href="#your-link">
        <i class="fas fa-circle fa-stack-2x"></i>
        <i class="fab fa-linkedin-in fa-stack-1x"></i>
      </a>
    </span>
            </div>
        </div>-->
        <!-- end of col -->
    </div>
    <!-- end of row -->
  </div>
  <!-- end of container -->
  </div>
  <!-- end of footer -->
  <!-- end of footer -->
  <!-- Copyright -->
  <div class="copyright">
  <div class="container">
    <div class="row">
        <div class="col-lg-12">
            <p class="p-small">Copyright © 2020 <a href="https://inovatik.com">Inovatik</a> - All rights reserved</p>
        </div>
        <!-- end of col -->
    </div>
    <!-- enf of row -->
  </div>
  <!-- end of container -->
  </div>
  <!-- end of copyright -->
  <!-- end of copyright -->
  <!-- Scripts -->
  <!--Script for ckeditor -->
  <script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
  <script>
  // CKEDITOR.replace('doc');
  CKEDITOR.replace('textcontent',{height:'500px'});

  function save() {
    var data = CKEDITOR.instances["contentid"].getData();
    var myAnchor = document.getElementById("contentid");
    var outputAnchor = document.getElementById("doc");
    var mySpan = document.createElement("div");
    mySpan.setAttribute('id', 'source-html');

    mySpan.innerHTML = data;
    var ele = document.getElementById('source-html');
   
    if (typeof(outputAnchor.childNodes[0]) != 'undefined' && outputAnchor.childNodes[0] != null) {
       
        outputAnchor.removeChild(outputAnchor.childNodes[0]);
        outputAnchor.appendChild(mySpan);

    } else {
      
        outputAnchor.appendChild(mySpan);
    }
  }
  </script>
  <!--end of ckeditor-->
  <script type="text/javascript">
      function htmlrender() {
        var template = document.getElementById('contentid').value;
        var txt = document.getElementById('doc');
        txt.innerHTML = template;

      }

      function exportHTML() {
        var header = "<html xmlns:o='urn:schemas-microsoft-com:office:office' " +
            "xmlns:w='urn:schemas-microsoft-com:office:word' " +
            "xmlns='http://www.w3.org/TR/REC-html40'>" +
            "<head><title>Export HTML to Word Document with JavaScript</title></head><body>";
        var footer = "</body></html>";

        var sourceHTML = header + document.getElementById("source-html").innerHTML + footer;
          
        var source = 'data:application/vnd.ms-word;charset=utf-8,' + encodeURIComponent(sourceHTML);
        var fileDownload = document.createElement("a");
        document.body.appendChild(fileDownload);
        fileDownload.href = source;
        fileDownload.download = 'document.doc';
        fileDownload.click();
        document.body.removeChild(fileDownload);
      }
    function replaceNbsps(str) {
      var re = new RegExp(String.fromCharCode(160), "g");
      return str.replace(re, " ");
    }
    function exportPDF() {

        // var lMargin = 15; //left margin in mm
        // var rMargin = 15; //right margin in mm
        // var pdfInMM = 240; // width of A4 in mm
        // var doc = new jsPDF('p', 'mm', 'A4');
        // //var data = CKEDITOR.instances["contentid"].getData();
        var data = document.getElementById('contentid').value;
       // data =  data.replace(/&.*;/g,'');
   
        //var txt = jQuery(data).html();
        //doc.text(lMargin, 200, data);
        //doc.save('document.pdf');
        //var txt = jQuery(data).text();
        //var lines = doc.fromHTML(data, (pdfInMM - lMargin - rMargin));
        //var lines = doc.splitTextToSize(str, (pdfInMM - lMargin - rMargin));
        //var lines = doc.splitTextToSize(data, (pdfInMM - lMargin - rMargin));
        // doc.text(lMargin, 200, data);
        // doc.save('document.pdf');
        // var pdf = new jsPDF('p','mm','a4');
        // pdf.addHTML('',function() {
        //     pdf.save('web.pdf');
        // });
        
        /*Choose the element that our invoice is rendered in.
        const element = document.getElementById('contentid');
        // Choose the element and save the PDF for our user.
        var opt = {
              margin:       1,
              filename:     'document.pdf',
              image:        { type: 'jpeg', quality: 0.98 },
              html2canvas:  { scale: 2 },
              jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
            };

        // New Promise-based usage:
            html2pdf().set(opt).from(data).save();*/
            
            
         let mywindow = window.open('', 'PRINT', 'height=650,width=900,top=100,left=150');

          mywindow.document.write(`<html><head><title>Test pdf</title>`);
          mywindow.document.write('</head><body >');
          mywindow.document.write(data);
          mywindow.document.write('</body></html>');
        
          mywindow.document.close(); // necessary for IE >= 10
          mywindow.focus(); // necessary for IE >= 10
        
          mywindow.print();
          mywindow.close();
        
          return true; 
        
            
    }
   

    function previewPDF() {      
        var data = CKEDITOR.instances["contentid"].getData();
        $('.modal-body #pdftext').html(data);
        $('#previewModal').modal('show');
    }
    function docPrint(){
        var content = document.getElementById('source-html').innerHTML;
        var a = window.open('', '', 'height=500, width=500'); 
            a.document.write('<html>'); 
            a.document.write('<body> <h1> <br>'); 
            a.document.write(content); 
            a.document.write('</body></html>'); 
            a.document.close(); 
            a.print(); 
    }
    
     $(document).ready(function(){
                $('[data-toggle="tooltip"]').tooltip();
		  });
  </script>
  <script src="js/jquery.min.js"></script>
  <!-- jQuery for Bootstrap's JavaScript plugins -->
  <script src="js/popper.min.js"></script>
  <!-- Popper tooltip library for Bootstrap -->
  <!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>-->
  <script src="js/bootstrap.min.js"></script>
  <!-- Bootstrap framework -->
  <script src="js/jquery.easing.min.js"></script>
  <!-- jQuery Easing for smooth scrolling between anchors -->
  <script src="js/swiper.min.js"></script>
  <!-- Swiper for image and text sliders -->
  <script src="js/jquery.magnific-popup.js"></script>
  <!-- Magnific Popup for lightboxes -->
  <script src="js/validator.min.js"></script>
  <!-- Validator.js - Bootstrap plugin that validates forms -->
  <script src="js/scripts.js"></script>
  <!-- Custom scripts -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.0.272/jspdf.debug.js"></script>
  <script src="js/html2pdf/dist/html2pdf.bundle.min.js"></script>

   
  </body>

  </html>