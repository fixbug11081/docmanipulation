<form method="POST" action="http://localhost:8002/generate/driving-licence" accept-charset="UTF-8"><input name="_token" type="hidden" value="0EJ4d7A8NET9iiRvUY1MEqFHdsDJEUpXWguaI0sq">
<input name="_token" type="hidden" value="0EJ4d7A8NET9iiRvUY1MEqFHdsDJEUpXWguaI0sq">

<label for="zxczxc3123">Zxczxc3123</label>
<input name="xczc" type="text">
<br><label for="qeqwe">Qeqwe</label>
<input name="qeqweqw" type="text">
<br>
<input class="submit" name="submit" type="submit" value="submit">

</form>