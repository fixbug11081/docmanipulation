	<!DOCTYPE>
	<html>
	<head>

	</head>
	<title></title>
	<body>
    <a href="{{ URL::to('/customers/pdf') }}">Export PDF</a>
    		
	<center>
		<br><br><br><br>
	APPLICATION FORM FOR FINANCIAL ASSISTANCE SCHEME FOR
	EDUCATED<br>
	UNEMPLOYED PERSONS<br><br>
	@foreach($datas as $data)
	<table border="2">

	<tr border="2">
		<th width=20%>1. </th>
		<th width=40%>Name of the Applicant (in block letters)</th>
		<th width=40%>{{$data->name}}</th>
	</tr>
	<tr border="2">
		<th width=20%>2. </th>
		<th width=40%>Sex Male / Female</th>
		<th width=40%>{{$data->gender}}</th>
	</tr>
	<tr border="2">
		<th width=20%>3. </th>
		<th width=40%>Father’s/Husband’s name</th>
		<th>{{$data->gaurdian}}</th>
	</tr>
	<tr border="2">
		<th width=20%>4. </th>
		<th width=40%>Address for correspondence<br>
		Permanent address <br>
		Whether resident certificate enclosed<br>
	for a minimum period of 3 years where<br>
	loan is going to be availed</th>
		<th width=40%>{{$data->address}}</th>
	</tr>
	<tr border="2">
		<th width=20%>5. </th>
		<th width=40%>Date of birth and age </th>
		<th width=40%>{{$data->dob}}</th>
	</tr>
	</table>
	@endforeach
	</center>


	</body>
	</html>