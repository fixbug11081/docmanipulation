@extends('layouts.app') @section('content')
<div class="container">
    <div class="row justify-content-center">
        @include('admin.partialtwoleafmenu')
        <div class="col-md-6">
            <div class="card">

                <div class="card-header">
                   <a href="#" data-toggle="tooltip" title="DocMaster application form!"> Document Form</a>
                </div>

                <div class="card-body">
                    @if (session('status'))
                    <div class="alert alert-success" role="alert">
                        {{ session('status') }}
                    </div>
                    @endif

                    <div id="" class="grayFormSec">
                        <div class="container">
                            <div class="box">

                                <div class="form-group  appForm">
                                    @if ($message = Session::get('fail'))
                                    <div class="alert alert-success">
                                        <p>{{ $message }}</p>
                                    </div>
                                    @endif @if (count($errors) > 0)
                                    <div class="alert alert-danger">
                                        <ul>
                                            @foreach ($errors->all() as $error)
                                            <li><font color=red>{{ $error }}</fonr></li>
                                            @endforeach
                                        </ul>
                                    </div>

                                    @endif

                                    @if ($message = Session::get('success'))
                                    <div class="alert alert-success">
                                        <p>{{ $message }}</p>
                                    </div>
                                    @endif

                                    {{Form::open([ "url"=>"/admin/save/fields","method"=>"POST", "class"=>"build-form"])}}
                                    <div class="form-group">
                                        {{Form::label('Form name')}}
                                   {{Form::select('formname', $formname,null, ['class'=>'form-control-input', 'id'=>'formid'])}}
                                    </div>
                                    <div class="form-group">
                                        {{Form::label('Field Type')}}
                                        {{Form::select('fieldtype', $field, null,
                                        ['class'=>'form-control-input', 'id'=>'fieldtype'])}}
                                   <span class="glyphicon glyphicon-question-sign append text-info tip" data-tip="tip-fourth" >
                                         <i class="fa fa-question-circle" aria-hidden="true"></i>   
                                        </span>
                                        <div id="tip-fourth" class="tip-content d-none">
                                        <ul>
                                        <li>Text:Select for plain text field type</li>    
                                        <li>Checkbox</li>
                                            
                                                <li>Select the fieldtype for options</li>
                                                <li>Select the Group fields for options in form</li>
                                            
                                        <li>Text value get into box character by character,if it is checked.</li>
                                      </div>
                                    </div>
                                    <div class="form-group"  id="settextfield" >
                                    {{Form::checkbox('plainfield',null,1,['id'=>'plainfield'])}}
                                    {{Form::label('No group field')}} 
                                        <span class="append text-info tip" data-tip="tip-first">
                                        <i class="fa fa-question-circle" aria-hidden="true"></i>
                                        </span>
                                        <div id="tip-first" class="tip-content d-none">
                                        <h2>Plain text field</h2>
                                        <p>This will add the plain text field if it is checked.</p>
                                      </div>    
                                    </div>

                                    <div  class="form-group" id="optiongroupbox">
                                       {{Form::checkbox('groupfields',null,0,['id'=>'groupfields'])}}
                                        {{Form::label(' Group Fields  title')}}
                                        <span class="glyphicon glyphicon-question-sign append text-info tip" data-tip="tip-second" >
                                         <i class="fa fa-question-circle" aria-hidden="true"></i>   
                                        </span>
                                        <div id="tip-second" class="tip-content d-none">
                                        <h2>Grouping header</h2>
                                        <p>This will add checkbox options in one grouping head,if it is checked.</p>
                                      </div>   

                                    </div>
                                         <!--<div class="form-group hide-select" id="options" >
                                    {{Form::checkbox('optionfield',null,0,['id'=>'optionfield'])}}
                                    {{Form::label(' Set as option field')}} 
                                    </div>
                                    <div class="form-group hide-select" id="optionfieldsbox">
                                    <label>Select Group fields</label>    
                                {{Form::select('optiongroupfield', $optiongroupfield,null,['class'=>' form-control-select ' , 'id'=>'groupfieldid'])}}
                                    </div>-->
                                    <div class="form-group hide-select" id="optionfieldsbox">
                              
                                    </div>
                                    <div class="form-group">
                                        {{Form::label('Field name')}}
                                        {{Form::text('fieldname',null,['class'=>'form-control-input'])}}
                                        @if($errors->has('name'))
                                        <span class="text-danger">{{ $errors->first('name') }}</span>
                                        @endif
                                    </div>

                                    <div class="form-group">
                                    {{Form::checkbox('boxflag',null,0,['id'=>'boxflag'])}}
                                    {{Form::label('Value in box')}}
                                        <span class="glyphicon glyphicon-question-sign append text-info tip" data-tip="tip-third" >
                                         <i class="fa fa-question-circle" aria-hidden="true"></i>   
                                        </span>
                                        <div id="tip-third" class="tip-content d-none">
                                        <h2>Value in box</h2>
                                        <p>Text value get into box character by character,if it is checked.</p>
                                      </div>
                                    </div>
                                    <div class="form-group">
                                        {{Form::label('Label')}}
                                        {{Form::text('label',null,['class'=>'form-control-input'])}}
                                        @if($errors->has('name'))
                                        <span class="text-danger">{{ $errors->first('label') }}</span>
                                        @endif
                                    </div>
                                     <div class="form-group">
                                        {{Form::label('Tooltips')}}
                                        {{Form::text('tooltips',null,['class'=>'form-control-input'])}}
                                        @if($errors->has('name'))
                                        <span class="text-danger">{{ $errors->first('label') }}</span>
                                        @endif
                                    </div>
                                    
                                    <div class="form-group">
                                        {{Form::label('sequence')}}
                                        {{Form::text('sequence',null,['class'=>'form-control-input'])}}
                                        @if($errors->has('name'))
                                        <span class="text-danger">{{ $errors->first('sequence') }}</span>
                                        @endif
                                    </div>

                                    <div class="form-group">
                                        {{Form::submit('submit', ['name'=>'submit', 'class'=>'submit btn btn-primary' ])}}
                                        {{Form::button('refresh', ['name'=>'refresh', 'class'=>'refresh btn btn-primary' ])}}
                                        {{Form::close()}}
                                    </div> 
                                </div>   

                            </div>
                        </div>
                    </div> 

                </div>

            </div>
        </div>
       
        @if($urlsegment == 'edit-application-form' )
        <div class="col-md-3">
            <div class="card">
            <form action="/admin/delete/fields/{{$formid}}/{{$tablename}}" method="get">    
                <div class="card-header">
                <h3 style="" class="align-del-bttn"> Form Fields </h3>
                <button style="" class="del-button">Delete</button>
                </div>
                <ul class="list-group list-group-flush">
                   @foreach($attributes as $attribute)  
                    <li class="list-group-item form-fields-right">
                    <input type="checkbox"value={{$attribute->fieldname}} name=fieldcheckbox[] style="">
                    <label>{{$attribute->fieldname}}</label>
                    </li>
                   @endforeach
                </ul>
                </div>
            </form>
            </div>
        </div>
        @else
        @endif
</div>
@endsection
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

        <script type="text/javascript">
        $(document).ready(function(){
                $('[data-toggle="tooltip"]').tooltip();
                $('.tip').each(function () {
                    	$(this).tooltip(
                    	{
                    		html: true,
                    		title: $('#' + $(this).data('tip')).html()
                    	});
                    });
                
                
                $('.refresh').click(function(e){
                    $('.build-form').trigger('reset');
                });
                $('#plainfield').change(function(){
               
                    if($(this).is(':checked')){
                        $('#groupfields').prop("checked",true);
                        $('#optiongroupbox').addClass('hide-select');
                         $('#optionfieldsbox').addClass('hide-select');  
                    }else{
                         $('#optiongroupbox').removeClass('hide-select');
                        
                    }
                });
                $('#groupfields').change(function(){
                  
                    if($(this).is(':checked')){
                        $('#optionfieldsbox').addClass('hide-select');  
                       
                    }else{
                       // $('#optionfieldsbox').removeClass('hide-select'); 
                      
                    }
                });
                $('#fieldtype').change(function(){
             
                    
                    var optionfield= $('#fieldtype').val();
                    var formid = $('#formid').val();
                   
                    if(optionfield == 3){
                       
                        $('#optiongroupbox').addClass('hide-select');
                        $('#settextfield').addClass('hide-select');
                        $('#optionfieldsbox').removeClass('hide-select');
                               
                            $.ajax({
                                type:'GET',
                                url:'/get/options/'+formid,
                                success: function(response){
                            
                                    $('#optionfieldsbox').html(response);
                                   
                                },
                                error:function(xhr){
                                    $('#optionfieldsbox').html("<p>Ajax call</p>");
                                    alert('error'+xhr.responseText);
                                }
                            });
                            
                        
                    }else{
                        $('#optiongroupbox').removeClass('hide-select');
                        $('#settextfield').removeClass('hide-select');
                        $('#optionfieldsbox').addClass('hide-select');
                    }
                });
                
         });
           </script>